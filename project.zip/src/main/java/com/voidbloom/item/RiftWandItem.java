package com.voidbloom.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Жезл Разлома.
 * ПКМ — «рывок через разлом»: телепорт на взгляд до 16 блоков (упирается в стены).
 * Shift + ПКМ — «зов эха»: притягивает всех живых существ в радиусе 8 блоков,
 * вешает на них свечение и слабость.
 */
public class RiftWandItem extends Item {
    private static final double BLINK_RANGE = 16.0D;
    private static final double PULL_RADIUS = 8.0D;

    public RiftWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        boolean used;
        if (player.isShiftKeyDown()) {
            used = pull((ServerLevel) level, player);
            if (used) player.getCooldowns().addCooldown(this, 100);
        } else {
            used = blink((ServerLevel) level, (ServerPlayer) player);
            if (used) player.getCooldowns().addCooldown(this, 40);
        }

        if (used) {
            stack.hurtAndBreak(1, player, pl -> pl.broadcastBreakEvent(hand));
            return InteractionResultHolder.consume(stack);
        }
        return InteractionResultHolder.fail(stack);
    }

    private boolean blink(ServerLevel level, ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(BLINK_RANGE));
        BlockHitResult hit = level.clip(new ClipContext(eye, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));

        Vec3 targetEye = hit.getType() == HitResult.Type.MISS
                ? end
                : hit.getLocation().subtract(look.scale(0.6D));
        Vec3 dest = targetEye.subtract(0, player.getEyeHeight(), 0);

        // Ищем свободное место: на месте, на блок выше, на блок ниже.
        Vec3 chosen = null;
        for (double dy : new double[]{0, 1, -1}) {
            Vec3 candidate = dest.add(0, dy, 0);
            AABB moved = player.getBoundingBox().move(candidate.subtract(player.position()));
            if (level.noCollision(player, moved)) {
                chosen = candidate;
                break;
            }
        }
        if (chosen == null || chosen.distanceToSqr(player.position()) < 2.0D) {
            return false;
        }

        level.sendParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1, player.getZ(),
                40, 0.3, 0.6, 0.3, 0.1);
        level.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
        player.teleportTo(chosen.x, chosen.y, chosen.z);
        player.resetFallDistance();
        level.sendParticles(ParticleTypes.PORTAL, chosen.x, chosen.y + 1, chosen.z, 40, 0.3, 0.6, 0.3, 0.2);
        level.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 0.8F);
        return true;
    }

    private boolean pull(ServerLevel level, Player player) {
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class,
                player.getBoundingBox().inflate(PULL_RADIUS),
                e -> e != player && e.isAlive() && !e.isSpectator());
        if (targets.isEmpty()) {
            return false;
        }
        for (LivingEntity target : targets) {
            Vec3 dir = player.position().subtract(target.position()).normalize().scale(1.1D);
            target.setDeltaMovement(dir.x, 0.35D, dir.z);
            target.hurtMarked = true;
            target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100));
        }
        level.sendParticles(ParticleTypes.SONIC_BOOM, player.getX(), player.getY() + 1, player.getZ(), 1, 0, 0, 0, 0);
        level.playSound(null, player.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 0.6F, 1.6F);
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @org.jetbrains.annotations.Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.voidbloom.rift_wand.tooltip1"));
        tooltip.add(Component.translatable("item.voidbloom.rift_wand.tooltip2"));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
