package com.voidbloom;

import com.voidbloom.event.ModEvents;
import com.voidbloom.net.ModNetwork;
import com.voidbloom.registry.ModBlockEntities;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModEntities;
import com.voidbloom.registry.ModItems;
import com.voidbloom.registry.ModMenus;
import com.voidbloom.registry.ModTabs;
import net.fabricmc.api.ModInitializer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public class VoidbloomMod implements ModInitializer {
    public static final String MODID = "voidbloom";

    /** Ключ нового измерения: data/voidbloom/dimension/echo_expanse.json */
    public static final ResourceKey<Level> ECHO_EXPANSE =
            ResourceKey.create(Registries.DIMENSION, id("echo_expanse"));

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MODID, path);
    }

    @Override
    public void onInitialize() {
        // порядок важен: блоки -> сущности -> предметы -> остальное
        ModBlocks.init();
        ModEntities.init();
        ModBlockEntities.init();
        ModMenus.init();
        ModItems.init();
        ModTabs.init();
        ModEvents.register();
        ModNetwork.registerServer();
    }
}
