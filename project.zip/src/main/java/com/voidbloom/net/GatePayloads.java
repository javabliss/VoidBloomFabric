package com.voidbloom.net;

import com.voidbloom.VoidbloomMod;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;

public class GatePayloads {
    public record Entry(BlockPos pos, String dim, String name) {}

    /** Сервер -> клиент: открыть/обновить экран врат. */
    public record Open(BlockPos current, String dim, boolean canEdit, List<Entry> gates) {
        public static final ResourceLocation ID = VoidbloomMod.id("gate_open");

        public static void write(FriendlyByteBuf buf, Open p) {
            buf.writeBlockPos(p.current);
            buf.writeUtf(p.dim);
            buf.writeBoolean(p.canEdit);
            buf.writeVarInt(p.gates.size());
            for (Entry e : p.gates) {
                buf.writeBlockPos(e.pos);
                buf.writeUtf(e.dim);
                buf.writeUtf(e.name, 64);
            }
        }

        public static Open read(FriendlyByteBuf buf) {
            BlockPos cur = buf.readBlockPos();
            String dim = buf.readUtf();
            boolean edit = buf.readBoolean();
            int n = buf.readVarInt();
            List<Entry> list = new ArrayList<>();
            for (int i = 0; i < n; i++) list.add(new Entry(buf.readBlockPos(), buf.readUtf(), buf.readUtf(64)));
            return new Open(cur, dim, edit, list);
        }
    }

    /** Клиент -> сервер: переименовать (0) или телепортироваться (1). */
    public record Action(int action, BlockPos from, BlockPos target, String targetDim, String name) {
        public static final ResourceLocation ID = VoidbloomMod.id("gate_action");

        public static void write(FriendlyByteBuf buf, Action p) {
            buf.writeVarInt(p.action);
            buf.writeBlockPos(p.from);
            buf.writeBlockPos(p.target);
            buf.writeUtf(p.targetDim);
            buf.writeUtf(p.name, 64);
        }

        public static Action read(FriendlyByteBuf buf) {
            return new Action(buf.readVarInt(), buf.readBlockPos(), buf.readBlockPos(), buf.readUtf(), buf.readUtf(64));
        }
    }
}
