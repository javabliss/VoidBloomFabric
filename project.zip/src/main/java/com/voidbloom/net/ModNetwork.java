package com.voidbloom.net;

import com.voidbloom.waypoint.GateService;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class ModNetwork {
    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(GatePayloads.Action.ID, (server, player, handler, buf, sender) -> {
            GatePayloads.Action a = GatePayloads.Action.read(buf);
            server.execute(() -> GateService.handle(player, a));
        });
    }
}
