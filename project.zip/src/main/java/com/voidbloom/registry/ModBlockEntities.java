package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.ResonanceForgeBlockEntity;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntityType;

public class ModBlockEntities {
    public static void init() {}

    public static final Registrar<BlockEntityType<?>> BLOCK_ENTITIES = new Registrar<>(BuiltInRegistries.BLOCK_ENTITY_TYPE);

    public static final Reg<BlockEntityType<ResonanceForgeBlockEntity>> RESONANCE_FORGE =
            BLOCK_ENTITIES.register("resonance_forge", () ->
                    BlockEntityType.Builder.of(ResonanceForgeBlockEntity::new, ModBlocks.RESONANCE_FORGE.get()).build(null));
}
