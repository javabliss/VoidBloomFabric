package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.entity.EchoDrifterEntity;
import com.voidbloom.entity.EchoGuardianEntity;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.entity.EchoVillagerEntity;
import com.voidbloom.entity.GlowPuffEntity;
import com.voidbloom.entity.HollowStalkerEntity;
import com.voidbloom.entity.ShardlingEntity;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class ModEntities {
    public static void init() {}

    public static final Registrar<EntityType<?>> ENTITIES = new Registrar<>(BuiltInRegistries.ENTITY_TYPE);

    public static final Reg<EntityType<ShardlingEntity>> SHARDLING =
            ENTITIES.register("shardling", () -> EntityType.Builder
                    .of(ShardlingEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.7F).clientTrackingRange(8)
                    .build("shardling"));

    public static final Reg<EntityType<HollowStalkerEntity>> HOLLOW_STALKER =
            ENTITIES.register("hollow_stalker", () -> EntityType.Builder
                    .of(HollowStalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.9F).clientTrackingRange(10)
                    .build("hollow_stalker"));

    public static final Reg<EntityType<GlowPuffEntity>> GLOW_PUFF =
            ENTITIES.register("glow_puff", () -> EntityType.Builder
                    .of(GlowPuffEntity::new, MobCategory.CREATURE)
                    .sized(0.9F, 0.9F).clientTrackingRange(8)
                    .build("glow_puff"));

    public static final Reg<EntityType<EchoSovereignEntity>> ECHO_SOVEREIGN =
            ENTITIES.register("echo_sovereign", () -> EntityType.Builder
                    .of(EchoSovereignEntity::new, MobCategory.MONSTER)
                    .sized(1.4F, 4.4F).fireImmune().clientTrackingRange(12)
                    .build("echo_sovereign"));

    public static final Reg<EntityType<EchoDrifterEntity>> ECHO_DRIFTER =
            ENTITIES.register("echo_drifter", () -> EntityType.Builder
                    .of(EchoDrifterEntity::new, MobCategory.CREATURE)
                    .sized(0.8F, 0.8F).clientTrackingRange(8)
                    .build("echo_drifter"));

    public static final Reg<EntityType<EchoGuardianEntity>> ECHO_GUARDIAN =
            ENTITIES.register("echo_guardian", () -> EntityType.Builder
                    .of(EchoGuardianEntity::new, MobCategory.MONSTER)
                    .sized(0.9F, 2.6F).fireImmune().clientTrackingRange(10)
                    .build("echo_guardian"));

    public static final Reg<EntityType<EchoVillagerEntity>> ECHO_VILLAGER =
            ENTITIES.register("echo_villager", () -> EntityType.Builder
                    .of(EchoVillagerEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10)
                    .build("echo_villager"));
}
