package com.voidbloom.registry;

import com.voidbloom.menu.ResonanceForgeMenu;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.inventory.MenuType;

public class ModMenus {
    public static void init() {}

    public static final Registrar<MenuType<?>> MENUS = new Registrar<>(BuiltInRegistries.MENU);

    public static final Reg<MenuType<ResonanceForgeMenu>> RESONANCE_FORGE =
            MENUS.register("resonance_forge", () -> new ExtendedScreenHandlerType<>(ResonanceForgeMenu::new));
}
