package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.item.RiftWandItem;
import com.voidbloom.item.ElixirItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.SpawnEggItem;

public class ModItems {
    public static void init() {}

    public static final Registrar<Item> ITEMS = new Registrar<>(BuiltInRegistries.ITEM);

    public static final Reg<Item> ECHO_CRYSTAL = ITEMS.registerSimpleItem("echo_crystal");

    // --- Инструменты ---
    public static final Reg<SwordItem> ECHO_SWORD = ITEMS.register("echo_sword",
            () -> new SwordItem(ModTiers.ECHO, (int) 3, -2.4F, new Item.Properties()));
    public static final Reg<PickaxeItem> ECHO_PICKAXE = ITEMS.register("echo_pickaxe",
            () -> new PickaxeItem(ModTiers.ECHO, (int) 1.0F, -2.8F, new Item.Properties()));
    public static final Reg<AxeItem> ECHO_AXE = ITEMS.register("echo_axe",
            () -> new AxeItem(ModTiers.ECHO, 5.0F, -3.0F, new Item.Properties()));
    public static final Reg<ShovelItem> ECHO_SHOVEL = ITEMS.register("echo_shovel",
            () -> new ShovelItem(ModTiers.ECHO, 1.5F, -3.0F, new Item.Properties()));
    public static final Reg<HoeItem> ECHO_HOE = ITEMS.register("echo_hoe",
            () -> new HoeItem(ModTiers.ECHO, (int) -2.0F, -0.5F, new Item.Properties()));

    // --- Броня ---
    public static final Reg<ArmorItem> ECHO_HELMET = ITEMS.register("echo_helmet",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.HELMET,
                    new Item.Properties()));
    public static final Reg<ArmorItem> ECHO_CHESTPLATE = ITEMS.register("echo_chestplate",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.CHESTPLATE,
                    new Item.Properties()));
    public static final Reg<ArmorItem> ECHO_LEGGINGS = ITEMS.register("echo_leggings",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.LEGGINGS,
                    new Item.Properties()));
    public static final Reg<ArmorItem> ECHO_BOOTS = ITEMS.register("echo_boots",
            () -> new ArmorItem(ModArmor.ECHO, ArmorItem.Type.BOOTS,
                    new Item.Properties()));

    // --- Уникальный предмет (падает только с босса) ---
    public static final Reg<RiftWandItem> RIFT_WAND = ITEMS.register("rift_wand",
            () -> new RiftWandItem(new Item.Properties().stacksTo(1).durability(320).rarity(Rarity.EPIC)));


    // --- Еда ---
    public static final Reg<Item> BLOOM_FRUIT = ITEMS.register("bloom_fruit",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationMod(0.4F).build())));
    public static final Reg<Item> CANDIED_SHARD = ITEMS.register("candied_shard",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationMod(0.3F).alwaysEat()
                    .effect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 1), 1.0F).build())));
    public static final Reg<Item> ECHO_PIE = ITEMS.register("echo_pie",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationMod(0.8F)
                    .effect(new MobEffectInstance(MobEffects.REGENERATION, 120, 0), 1.0F)
                    .effect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 0), 1.0F).build())));
    public static final Reg<Item> RAW_PUFFMEAT = ITEMS.register("raw_puffmeat",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationMod(0.2F).build())));
    public static final Reg<Item> COOKED_PUFFMEAT = ITEMS.register("cooked_puffmeat",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(7).saturationMod(0.7F).build())));
    public static final Reg<net.minecraft.world.item.DoubleHighBlockItem> ECHO_DOOR = ITEMS.register("echo_door",
            () -> new net.minecraft.world.item.DoubleHighBlockItem(ModBlocks.ECHO_DOOR.get(), new Item.Properties()));


    // --- Руды трёх миров и резонит ---
    public static final Reg<Item> SCORCHITE_SHARD = ITEMS.registerSimpleItem("scorchite_shard", new Item.Properties().fireResistant());
    public static final Reg<Item> UMBRALITE_CHUNK = ITEMS.registerSimpleItem("umbralite_chunk");
    public static final Reg<Item> LUMINA_GEM = ITEMS.registerSimpleItem("lumina_gem");
    public static final Reg<Item> RESONITE_INGOT = ITEMS.registerSimpleItem("resonite_ingot", new Item.Properties().fireResistant().rarity(Rarity.RARE));
    public static final Reg<Item> RESONITE_TEMPLATE = ITEMS.registerSimpleItem("resonite_upgrade_smithing_template", new Item.Properties().rarity(Rarity.RARE));

    public static final Reg<SwordItem> RESONITE_SWORD = ITEMS.register("resonite_sword",
            () -> new SwordItem(ModTiers.RESONITE, (int) 3, -2.4F, new Item.Properties().fireResistant()));
    public static final Reg<PickaxeItem> RESONITE_PICKAXE = ITEMS.register("resonite_pickaxe",
            () -> new PickaxeItem(ModTiers.RESONITE, (int) 1.0F, -2.8F, new Item.Properties().fireResistant()));
    public static final Reg<AxeItem> RESONITE_AXE = ITEMS.register("resonite_axe",
            () -> new AxeItem(ModTiers.RESONITE, 5.0F, -3.0F, new Item.Properties().fireResistant()));
    public static final Reg<ShovelItem> RESONITE_SHOVEL = ITEMS.register("resonite_shovel",
            () -> new ShovelItem(ModTiers.RESONITE, 1.5F, -3.0F, new Item.Properties().fireResistant()));
    public static final Reg<HoeItem> RESONITE_HOE = ITEMS.register("resonite_hoe",
            () -> new HoeItem(ModTiers.RESONITE, (int) -4.0F, 0.0F, new Item.Properties().fireResistant()));
    public static final Reg<ArmorItem> RESONITE_HELMET = ITEMS.register("resonite_helmet",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.HELMET,
                    new Item.Properties().fireResistant()));
    public static final Reg<ArmorItem> RESONITE_CHESTPLATE = ITEMS.register("resonite_chestplate",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.CHESTPLATE,
                    new Item.Properties().fireResistant()));
    public static final Reg<ArmorItem> RESONITE_LEGGINGS = ITEMS.register("resonite_leggings",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.LEGGINGS,
                    new Item.Properties().fireResistant()));
    public static final Reg<ArmorItem> RESONITE_BOOTS = ITEMS.register("resonite_boots",
            () -> new ArmorItem(ModArmor.RESONITE, ArmorItem.Type.BOOTS,
                    new Item.Properties().fireResistant()));

    public static final Reg<Item> STARDUST = ITEMS.registerSimpleItem("stardust");

    public static final Reg<Item> ECHO_BLOOM_SEEDS = ITEMS.register("echo_bloom_seeds",
            () -> new ItemNameBlockItem(ModBlocks.ECHO_BLOOM.get(), new Item.Properties()));
    public static final Reg<Item> ECHO_BLOOM_FLOWER = ITEMS.register("echo_bloom_flower",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder().nutrition(2).saturationMod(0.3F).fast().build())));
    public static final Reg<ElixirItem> ELIXIR_SIGHT = ITEMS.register("elixir_sight",
            () -> new ElixirItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(0).saturationMod(0.0F).alwaysEat()
                    .effect(new MobEffectInstance(MobEffects.NIGHT_VISION, 6000, 0), 1.0F)
                    .effect(new MobEffectInstance(MobEffects.GLOWING, 1200, 0), 1.0F).build())));
    public static final Reg<ElixirItem> ELIXIR_STARSTEP = ITEMS.register("elixir_starstep",
            () -> new ElixirItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(0).saturationMod(0.0F).alwaysEat()
                    .effect(new MobEffectInstance(MobEffects.JUMP, 3600, 2), 1.0F)
                    .effect(new MobEffectInstance(MobEffects.SLOW_FALLING, 3600, 0), 1.0F).build())));
    public static final Reg<ElixirItem> ELIXIR_RESONANCE = ITEMS.register("elixir_resonance",
            () -> new ElixirItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder().nutrition(0).saturationMod(0.0F).alwaysEat()
                    .effect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 3600, 1), 1.0F)
                    .effect(new MobEffectInstance(MobEffects.ABSORPTION, 3600, 2), 1.0F)
                    .effect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1), 1.0F).build())));
    public static final Reg<SpawnEggItem> ECHO_DRIFTER_SPAWN_EGG = ITEMS.register("echo_drifter_spawn_egg",
            () -> new SpawnEggItem(ModEntities.ECHO_DRIFTER.get(), 0xFF8FC3, 0x7FF0E6, new Item.Properties()));
    public static final Reg<SpawnEggItem> ECHO_GUARDIAN_SPAWN_EGG = ITEMS.register("echo_guardian_spawn_egg",
            () -> new SpawnEggItem(ModEntities.ECHO_GUARDIAN.get(), 0x2F2A4C, 0x7FF0E6, new Item.Properties()));
    public static final Reg<SpawnEggItem> ECHO_VILLAGER_SPAWN_EGG = ITEMS.register("echo_villager_spawn_egg",
            () -> new SpawnEggItem(ModEntities.ECHO_VILLAGER.get(), 0xB88CF0, 0xFF8FC3, new Item.Properties()));

    // --- Яйца призыва ---
    public static final Reg<SpawnEggItem> SHARDLING_SPAWN_EGG = ITEMS.register("shardling_spawn_egg",
            () -> new SpawnEggItem(ModEntities.SHARDLING.get(), 0x6B3FA0, 0xD9B8FF, new Item.Properties()));
    public static final Reg<SpawnEggItem> HOLLOW_STALKER_SPAWN_EGG = ITEMS.register("hollow_stalker_spawn_egg",
            () -> new SpawnEggItem(ModEntities.HOLLOW_STALKER.get(), 0x14081F, 0xFF3FD0, new Item.Properties()));
    public static final Reg<SpawnEggItem> GLOW_PUFF_SPAWN_EGG = ITEMS.register("glow_puff_spawn_egg",
            () -> new SpawnEggItem(ModEntities.GLOW_PUFF.get(), 0x5AF0E6, 0xFFF59A, new Item.Properties()));
    public static final Reg<SpawnEggItem> ECHO_SOVEREIGN_SPAWN_EGG = ITEMS.register("echo_sovereign_spawn_egg",
            () -> new SpawnEggItem(ModEntities.ECHO_SOVEREIGN.get(), 0x2A0A3F, 0xC77DFF, new Item.Properties()));
}
