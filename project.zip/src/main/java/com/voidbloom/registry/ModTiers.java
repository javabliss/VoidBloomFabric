package com.voidbloom.registry;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public class ModTiers {
    private static Tier make(int uses, float speed, float dmg, int level, int ench, Supplier<Ingredient> repair) {
        return new Tier() {
            public int getUses() { return uses; }
            public float getSpeed() { return speed; }
            public float getAttackDamageBonus() { return dmg; }
            public int getLevel() { return level; }
            public int getEnchantmentValue() { return ench; }
            public Ingredient getRepairIngredient() { return repair.get(); }
        };
    }

    /** Чуть лучше алмаза по скорости и урону, прочность ниже незерита. */
    public static final Tier ECHO = make(1800, 8.5F, 3.5F, 3, 18, () -> Ingredient.of(ModItems.ECHO_CRYSTAL.get()));

    /** Выше незерита: прочность 3600, скорость 10, урон +5. */
    public static final Tier RESONITE = make(3600, 10.0F, 5.0F, 4, 22, () -> Ingredient.of(ModItems.RESONITE_INGOT.get()));
}
