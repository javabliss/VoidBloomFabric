package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.ArenaCoreBlock;
import com.voidbloom.block.EchoBloomCropBlock;
import com.voidbloom.block.EchoDetectorBlock;
import com.voidbloom.block.EchoGateBlock;
import com.voidbloom.block.EchoLauncherBlock;
import com.voidbloom.block.EchoPulserBlock;
import com.voidbloom.block.EchoReceiverBlock;
import com.voidbloom.block.EchoTransmitterBlock;
import com.voidbloom.block.ResonanceHullBlock;
import com.voidbloom.block.ResonanceForgeBlock;
import com.voidbloom.block.RiftPortalBlock;
import com.voidbloom.block.SovereignAltarBlock;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;

import java.util.function.Supplier;

public class ModBlocks {
    public static void init() {}

    public static final Registrar<Block> BLOCKS = new Registrar<>(BuiltInRegistries.BLOCK);

    public static final Reg<Block> ECHO_STONE = registerWithItem("echo_stone",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(2.0F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE)));

    public static final Reg<Block> ECHO_SOIL = registerWithItem("echo_soil",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE)
                    .strength(0.8F).sound(SoundType.MOSS)));

    public static final Reg<Block> ECHO_CRYSTAL_ORE = registerWithItem("echo_crystal_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE).strength(3.5F, 4.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 5).sound(SoundType.AMETHYST), UniformInt.of(3, 7)));

    public static final Reg<Block> ECHO_CRYSTAL_BLOCK = registerWithItem("echo_crystal_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(5.0F, 8.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 9).sound(SoundType.AMETHYST)));

    public static final Reg<Block> RIFT_FRAME = registerWithItem("rift_frame",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(30.0F, 1200.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 4).sound(SoundType.DEEPSLATE_BRICKS)));

    public static final Reg<RiftPortalBlock> RIFT_PORTAL = BLOCKS.register("rift_portal",
            () -> new RiftPortalBlock(BlockBehaviour.Properties.of().noCollission().noLootTable()
                    .strength(-1.0F).lightLevel(s -> 11).sound(SoundType.GLASS)
                    .pushReaction(net.minecraft.world.level.material.PushReaction.BLOCK)));

    public static final Reg<RotatedPillarBlock> VOID_LOG = registerWithItem("void_log",
            () -> new RotatedPillarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK)
                    .strength(2.0F).sound(SoundType.WOOD).ignitedByLava()));

    public static final Reg<LeavesBlock> VOID_LEAVES = registerWithItem("void_leaves",
            () -> new LeavesBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_MAGENTA)
                    .strength(0.2F).randomTicks().noOcclusion().lightLevel(s -> 6)
                    .sound(SoundType.AZALEA_LEAVES)
                    .isValidSpawn((state, level, pos, type) -> false)
                    .isSuffocating((s, l, p) -> false).isViewBlocking((s, l, p) -> false)));

    public static final Reg<SovereignAltarBlock> SOVEREIGN_ALTAR = registerWithItem("sovereign_altar",
            () -> new SovereignAltarBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE)
                    .strength(50.0F, 1200.0F).requiresCorrectToolForDrops()
                    .lightLevel(s -> 12).sound(SoundType.AMETHYST)));


    private static BlockBehaviour.Properties wood() {
        return BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(2.0F, 3.0F).sound(SoundType.CHERRY_WOOD).ignitedByLava();
    }
    public static final Reg<Block> ECHO_MOSS = registerWithItem("echo_moss",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(0.8F).sound(SoundType.MOSS)));
    public static final Reg<Block> ECHO_BRICKS = registerWithItem("echo_bricks",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(2.0F, 6.0F)
                    .requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE_BRICKS)));
    public static final Reg<Block> ECHO_PLANKS = registerWithItem("echo_planks", () -> new Block(wood()));
    public static final Reg<StairBlock> ECHO_STAIRS = registerWithItem("echo_stairs",
            () -> new StairBlock(ECHO_PLANKS.get().defaultBlockState(), wood()));
    public static final Reg<SlabBlock> ECHO_SLAB = registerWithItem("echo_slab", () -> new SlabBlock(wood()));
    public static final Reg<FenceBlock> ECHO_FENCE = registerWithItem("echo_fence", () -> new FenceBlock(wood()));
    public static final Reg<FenceGateBlock> ECHO_FENCE_GATE = registerWithItem("echo_fence_gate",
            () -> new FenceGateBlock(wood(), WoodType.CHERRY));
    public static final Reg<DoorBlock> ECHO_DOOR = BLOCKS.register("echo_door",
            () -> new DoorBlock(wood().noOcclusion(), BlockSetType.CHERRY));
    public static final Reg<TrapDoorBlock> ECHO_TRAPDOOR = registerWithItem("echo_trapdoor",
            () -> new TrapDoorBlock(wood().noOcclusion(), BlockSetType.CHERRY));
    public static final Reg<ButtonBlock> ECHO_BUTTON = registerWithItem("echo_button",
            () -> new ButtonBlock(wood().noCollission().strength(0.5F), BlockSetType.CHERRY, 30, true));
    public static final Reg<PressurePlateBlock> ECHO_PRESSURE_PLATE = registerWithItem("echo_pressure_plate",
            () -> new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, wood().noCollission().strength(0.5F), BlockSetType.CHERRY));

    private static BlockBehaviour.Properties ore(MapColor c, int light, SoundType snd) {
        return BlockBehaviour.Properties.of().mapColor(c).strength(4.5F, 6.0F).requiresCorrectToolForDrops().lightLevel(s -> light).sound(snd);
    }
    public static final Reg<Block> SCORCHITE_ORE = registerWithItem("scorchite_ore",
            () -> new DropExperienceBlock(ore(MapColor.NETHER, 7, SoundType.NETHER_ORE), UniformInt.of(4, 8)));
    public static final Reg<Block> UMBRALITE_ORE = registerWithItem("umbralite_ore",
            () -> new DropExperienceBlock(ore(MapColor.SAND, 5, SoundType.STONE), UniformInt.of(4, 8)));
    public static final Reg<Block> LUMINA_ORE = registerWithItem("lumina_ore",
            () -> new DropExperienceBlock(ore(MapColor.GOLD, 9, SoundType.AMETHYST), UniformInt.of(3, 7)));
    public static final Reg<Block> RESONITE_BLOCK = registerWithItem("resonite_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(50.0F, 1200.0F)
                    .requiresCorrectToolForDrops().lightLevel(s -> 6).sound(SoundType.NETHERITE_BLOCK)));
    public static final Reg<ResonanceForgeBlock> RESONANCE_FORGE = registerWithItem("resonance_forge",
            () -> new ResonanceForgeBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(10.0F, 600.0F)
                    .requiresCorrectToolForDrops().lightLevel(s -> 8).sound(SoundType.DEEPSLATE_BRICKS)));

    public static final Reg<Block> ECHO_JELLY = registerWithItem("echo_jelly",
            () -> new SlimeBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).friction(0.8F)
                    .sound(SoundType.SLIME_BLOCK).noOcclusion()));
    public static final Reg<Block> ECHO_LAMP = registerWithItem("echo_lamp",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(0.5F)
                    .lightLevel(s -> 15).sound(SoundType.GLASS)));
    public static final Reg<Block> ECHO_GLASS = registerWithItem("echo_glass",
            () -> new StainedGlassBlock(net.minecraft.world.item.DyeColor.CYAN, BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(0.3F)
                    .sound(SoundType.GLASS).noOcclusion().isValidSpawn((st, l, p, t) -> false)
                    .isRedstoneConductor((st, l, p) -> false).isSuffocating((st, l, p) -> false).isViewBlocking((st, l, p) -> false)));

    public static final Reg<ArenaCoreBlock> ARENA_CORE = registerWithItem("arena_core",
            () -> new ArenaCoreBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(-1.0F, 3600000.0F)
                    .lightLevel(s -> 10).sound(SoundType.DEEPSLATE_BRICKS).noLootTable()));
    public static final Reg<EchoGateBlock> ECHO_GATE = registerWithItem("echo_gate",
            () -> new EchoGateBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(3.0F, 8.0F)
                    .lightLevel(s -> 9).sound(SoundType.AMETHYST).noOcclusion()));
    public static final Reg<ResonanceHullBlock> RESONANCE_HULL = BLOCKS.register("resonance_hull",
            () -> new ResonanceHullBlock(BlockBehaviour.Properties.copy(ECHO_BRICKS.get())));
    public static final Reg<EchoDetectorBlock> ECHO_DETECTOR = registerWithItem("echo_detector",
            () -> new EchoDetectorBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(2.5F)
                    .sound(SoundType.AMETHYST).lightLevel(s -> s.getValue(EchoDetectorBlock.POWER) > 0 ? 7 : 0)));
    public static final Reg<EchoPulserBlock> ECHO_PULSER = registerWithItem("echo_pulser",
            () -> new EchoPulserBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(2.5F)
                    .sound(SoundType.AMETHYST).lightLevel(s -> s.getValue(EchoPulserBlock.POWERED) ? 7 : 0)));
    public static final Reg<EchoTransmitterBlock> ECHO_TRANSMITTER = registerWithItem("echo_transmitter",
            () -> new EchoTransmitterBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(2.5F)
                    .sound(SoundType.AMETHYST).lightLevel(s -> s.getValue(EchoTransmitterBlock.LIT) ? 8 : 0)));
    public static final Reg<EchoReceiverBlock> ECHO_RECEIVER = registerWithItem("echo_receiver",
            () -> new EchoReceiverBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).strength(2.5F)
                    .sound(SoundType.AMETHYST).lightLevel(s -> s.getValue(EchoReceiverBlock.LIT) ? 8 : 0)));
    public static final Reg<EchoLauncherBlock> ECHO_LAUNCHER = registerWithItem("echo_launcher",
            () -> new EchoLauncherBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_CYAN).strength(2.0F)
                    .sound(SoundType.AMETHYST).noOcclusion()));
    public static final Reg<EchoBloomCropBlock> ECHO_BLOOM = BLOCKS.register("echo_bloom",
            () -> new EchoBloomCropBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PINK).noCollission().randomTicks()
                    .instabreak().sound(SoundType.CROP).pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY).lightLevel(s -> 4)));

    private static <T extends Block> Reg<T> registerWithItem(String name, Supplier<T> block) {
        Reg<T> result = BLOCKS.register(name, block);
        Registry.register(BuiltInRegistries.ITEM, VoidbloomMod.id(name), new BlockItem(result.get(), new Item.Properties()));
        return result;
    }
}
