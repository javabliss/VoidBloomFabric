package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import net.minecraft.core.Registry;
import net.minecraft.world.item.Item;

import java.util.function.Supplier;

public class Registrar<T> {
    private final Registry<T> registry;

    public Registrar(Registry<T> registry) {
        this.registry = registry;
    }

    public <R extends T> Reg<R> register(String name, Supplier<R> supplier) {
        R value = supplier.get();
        Registry.register(registry, VoidbloomMod.id(name), value);
        return new Reg<>(value);
    }

    @SuppressWarnings("unchecked")
    public <R extends Item> Reg<R> registerSimpleItem(String name) {
        return (Reg<R>) ((Registrar<Item>) (Registrar<?>) this).register(name, () -> new Item(new Item.Properties()));
    }

    @SuppressWarnings("unchecked")
    public <R extends Item> Reg<R> registerSimpleItem(String name, Item.Properties props) {
        return (Reg<R>) ((Registrar<Item>) (Registrar<?>) this).register(name, () -> new Item(props));
    }
}
