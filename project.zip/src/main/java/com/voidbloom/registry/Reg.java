package com.voidbloom.registry;

import java.util.function.Supplier;

/** Простая обёртка: объект регистрируется сразу, get() возвращает его. */
public class Reg<T> implements Supplier<T> {
    private final T value;

    public Reg(T value) {
        this.value = value;
    }

    @Override
    public T get() {
        return value;
    }
}
