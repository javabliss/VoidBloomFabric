package com.voidbloom.registry;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.function.Supplier;

public class ModArmor {
    private static final int[] BASE_DURABILITY = {11, 16, 15, 13}; // helmet, chest, legs, boots

    private static ArmorMaterial make(String name, int mult, int[] defense, int ench, SoundEvent sound,
                                      float tough, float kb, Supplier<Ingredient> repair) {
        return new ArmorMaterial() {
            public int getDurabilityForType(ArmorItem.Type t) { return BASE_DURABILITY[t.ordinal()] * mult; }
            public int getDefenseForType(ArmorItem.Type t) { return defense[t.ordinal()]; }
            public int getEnchantmentValue() { return ench; }
            public SoundEvent getEquipSound() { return sound; }
            public Ingredient getRepairIngredient() { return repair.get(); }
            public String getName() { return name; }
            public float getToughness() { return tough; }
            public float getKnockbackResistance() { return kb; }
        };
    }

    /** Текстуры: assets/minecraft/textures/models/armor/voidbloom_echo_layer_1.png / _2.png */
    public static final ArmorMaterial ECHO = make("voidbloom_echo", 38, new int[]{3, 8, 6, 3}, 18,
            SoundEvents.ARMOR_EQUIP_DIAMOND, 2.5F, 0.05F, () -> Ingredient.of(ModItems.ECHO_CRYSTAL.get()));

    public static final ArmorMaterial RESONITE = make("voidbloom_resonite", 46, new int[]{4, 9, 7, 4}, 22,
            SoundEvents.ARMOR_EQUIP_NETHERITE, 4.0F, 0.15F, () -> Ingredient.of(ModItems.RESONITE_INGOT.get()));
}
