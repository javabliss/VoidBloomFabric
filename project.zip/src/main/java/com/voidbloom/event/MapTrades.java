package com.voidbloom.event;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.registry.ModItems;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

/** Картограф (в т.ч. эхо-житель) продаёт карты к структурам Бездны Эха, как ванильные карты клада. */
public class MapTrades {
    public static void register() {
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CARTOGRAPHER, 1, t -> {
            t.add(new MapListing("ruins", MapDecoration.Type.RED_X, 4, 8));
            t.add(new MapListing("camp", MapDecoration.Type.TARGET_X, 4, 8));
            t.add(new MapListing("obelisk", MapDecoration.Type.TARGET_POINT, 6, 8));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CARTOGRAPHER, 2, t -> {
            t.add(new MapListing("vault", MapDecoration.Type.MANSION, 8, 12));
            t.add(new MapListing("arena", MapDecoration.Type.MONUMENT, 8, 12));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.CARTOGRAPHER, 3, t ->
                t.add(new MapListing("sanctum", MapDecoration.Type.MANSION, 12, 16)));
    }

    public record MapListing(String target, MapDecoration.Type decoration, int cost, int xp) implements VillagerTrades.ItemListing {
        @Override
        public MerchantOffer getOffer(Entity trader, RandomSource random) {
            if (!(trader.level() instanceof ServerLevel level) || level.dimension() != VoidbloomMod.ECHO_EXPANSE) return null;
            TagKey<Structure> tag = TagKey.create(Registries.STRUCTURE, VoidbloomMod.id("map_" + target));
            BlockPos pos = level.findNearestMapStructure(tag, trader.blockPosition(), 100, true);
            if (pos == null) return null;
            ItemStack map = MapItem.create(level, pos.getX(), pos.getZ(), (byte) 2, true, true);
            MapItem.renderBiomePreviewMap(level, map);
            MapItemSavedData.addTargetDecoration(map, pos, "+", decoration);
            map.setHoverName(Component.translatable("item.voidbloom.map_" + target));
            return new MerchantOffer(new ItemStack(ModItems.ECHO_CRYSTAL.get(), cost), new ItemStack(Items.COMPASS),
                    map, 8, xp, 0.2F);
        }
    }
}
