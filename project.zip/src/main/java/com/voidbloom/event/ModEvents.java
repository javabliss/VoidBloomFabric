package com.voidbloom.event;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.block.PortalHelper;
import com.voidbloom.block.ResonanceForgeBlock;
import com.voidbloom.entity.*;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModEntities;
import com.voidbloom.registry.ModItems;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

import java.util.ArrayList;
import java.util.List;

public class ModEvents {
    private static final List<Object[]> PENDING = new ArrayList<>();

    public static void register() {
        // атрибуты
        FabricDefaultAttributeRegistry.register(ModEntities.SHARDLING.get(), ShardlingEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.HOLLOW_STALKER.get(), HollowStalkerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.GLOW_PUFF.get(), GlowPuffEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.ECHO_SOVEREIGN.get(), EchoSovereignEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.ECHO_DRIFTER.get(), EchoDrifterEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.ECHO_GUARDIAN.get(), EchoGuardianEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.ECHO_VILLAGER.get(), net.minecraft.world.entity.npc.Villager.createAttributes());

        // условия спавна (через access widener)
        SpawnPlacements.register(ModEntities.SHARDLING.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules);
        SpawnPlacements.register(ModEntities.HOLLOW_STALKER.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Monster::checkAnyLightMonsterSpawnRules);
        SpawnPlacements.register(ModEntities.ECHO_DRIFTER.get(), SpawnPlacements.Type.NO_RESTRICTIONS,
                Heightmap.Types.MOTION_BLOCKING, (type, lvl, reason, pos, rand) -> lvl.getBlockState(pos).isAir());
        SpawnPlacements.register(ModEntities.GLOW_PUFF.get(), SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mob::checkMobSpawnRules);

        // руды в Незере и Крае
        ResourceKey<PlacedFeature> scorchite = ResourceKey.create(Registries.PLACED_FEATURE, VoidbloomMod.id("ore_scorchite"));
        ResourceKey<PlacedFeature> umbralite = ResourceKey.create(Registries.PLACED_FEATURE, VoidbloomMod.id("ore_umbralite"));
        BiomeModifications.addFeature(BiomeSelectors.foundInTheNether(), GenerationStep.Decoration.UNDERGROUND_ORES, scorchite);
        BiomeModifications.addFeature(BiomeSelectors.foundInTheEnd(), GenerationStep.Decoration.UNDERGROUND_ORES, umbralite);

        // зажигание портала + сборка горна
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (level.isClientSide) return InteractionResult.PASS;
            ItemStack held = player.getItemInHand(hand);
            BlockPos clicked = hit.getBlockPos();
            if (held.is(Items.ECHO_SHARD) && level.getBlockState(clicked).is(ModBlocks.RIFT_FRAME.get())) {
                BlockPos start = clicked.relative(hit.getDirection());
                if (PortalHelper.tryLight(level, start)) {
                    level.playSound(null, start, SoundEvents.RESPAWN_ANCHOR_CHARGE, SoundSource.BLOCKS, 1.0F, 0.7F);
                    if (!player.getAbilities().instabuild) held.shrink(1);
                    return InteractionResult.SUCCESS;
                }
            }
            if (held.is(ModBlocks.ECHO_BRICKS.get().asItem()) || held.is(Items.MAGMA_BLOCK)) {
                PENDING.add(new Object[]{level, clicked.relative(hit.getDirection())});
            }
            return InteractionResult.PASS;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!PENDING.isEmpty()) {
                List<Object[]> copy = new ArrayList<>(PENDING);
                PENDING.clear();
                for (Object[] o : copy) {
                    ServerLevel level = (ServerLevel) o[0];
                    BlockPos p = (BlockPos) o[1];
                    for (BlockPos q : BlockPos.betweenClosed(p.offset(-3, -3, -3), p.offset(3, 3, 3))) {
                        if (level.getBlockState(q).is(ModBlocks.RESONANCE_FORGE.get())
                                && ResonanceForgeBlock.tryAssemble(level, q.immutable())) break;
                    }
                }
            }
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (p.tickCount % 40 != 0) continue;
                if (fullSet(p)) {
                    p.addEffect(new MobEffectInstance(MobEffects.JUMP, 100, 1, true, false));
                    if (p.level().dimension() == VoidbloomMod.ECHO_EXPANSE)
                        p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 320, 0, true, false));
                }
            }
        });
        AdventureEvents.register();
        MapTrades.register();
    }

    public static boolean fullSet(Player p) {
        return p.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.ECHO_HELMET.get())
                && p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.ECHO_CHESTPLATE.get())
                && p.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.ECHO_LEGGINGS.get())
                && p.getItemBySlot(EquipmentSlot.FEET).is(ModItems.ECHO_BOOTS.get());
    }
}
