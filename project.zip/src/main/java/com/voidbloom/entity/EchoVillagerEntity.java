package com.voidbloom.entity;

import com.voidbloom.registry.ModEntities;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.Level;

/** Эхо-житель: обычный житель со своей кожей (торговля, профессии, размножение как у ванильных). */
public class EchoVillagerEntity extends Villager {
    public EchoVillagerEntity(EntityType<? extends Villager> type, Level level) {
        super(type, level);
    }

    @Override
    public Villager getBreedOffspring(ServerLevel level, AgeableMob partner) {
        EchoVillagerEntity baby = ModEntities.ECHO_VILLAGER.get().create(level);
        if (baby != null) {
            baby.finalizeSpawn(level, level.getCurrentDifficultyAt(baby.blockPosition()), MobSpawnType.BREEDING, null, null);
        }
        return baby;
    }
}
