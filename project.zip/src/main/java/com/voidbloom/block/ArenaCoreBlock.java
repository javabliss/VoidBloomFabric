package com.voidbloom.block;

import com.voidbloom.registry.ModEntities;
import com.voidbloom.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Ядро арены: ПКМ четырьмя эхо-кристаллами запускает 4 волны врагов (последняя с Стражем).
 * Состояние WAVE: 0 — ожидание, 1-4 — предстоящая волна, 5 — все волны вызваны, ждём победу.
 */
public class ArenaCoreBlock extends Block {
    public static final IntegerProperty WAVE = IntegerProperty.create("wave", 0, 5);
    private static final String TAG = "vb_arena";

    public ArenaCoreBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(WAVE, 0));
    }


    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(WAVE);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack stack = player.getItemInHand(hand);
        if (!stack.is(ModItems.ECHO_CRYSTAL.get()) || stack.getCount() < 4 || state.getValue(WAVE) != 0) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (level.getDifficulty() == Difficulty.PEACEFUL) {
            player.displayClientMessage(Component.translatable("message.voidbloom.altar_peaceful"), true);
            return InteractionResult.CONSUME;
        }
        if (!player.getAbilities().instabuild) stack.shrink(4);
        level.setBlock(pos, state.setValue(WAVE, 1), 3);
        level.scheduleTick(pos, this, 40);
        level.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 2.0F, 0.5F);
        player.displayClientMessage(Component.translatable("message.voidbloom.arena_start"), false);
        return InteractionResult.CONSUME;
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int wave = state.getValue(WAVE);
        if (wave == 0) return;
        AABB area = new AABB(pos).inflate(26.0D, 10.0D, 26.0D);
        List<Player> players = level.getEntitiesOfClass(Player.class, area, p -> !p.isSpectator() && p.isAlive());
        if (players.isEmpty()) {
            for (Monster m : level.getEntitiesOfClass(Monster.class, area, m -> m.getTags().contains(TAG))) m.discard();
            level.setBlock(pos, state.setValue(WAVE, 0), 3);
            return;
        }
        long alive = level.getEntitiesOfClass(Monster.class, area, m -> m.getTags().contains(TAG) && m.isAlive()).size();
        if (alive > 0) {
            level.scheduleTick(pos, this, 40);
            return;
        }
        if (wave <= 4) {
            spawnWave(level, pos, wave, random);
            level.setBlock(pos, state.setValue(WAVE, wave + 1), 3);
            for (Player p : players) p.displayClientMessage(Component.translatable("message.voidbloom.arena_wave", wave), true);
            level.scheduleTick(pos, this, 60);
        } else {
            reward(level, pos, random);
            for (Player p : players) p.displayClientMessage(Component.translatable("message.voidbloom.arena_win"), false);
            level.setBlock(pos, state.setValue(WAVE, 0), 3);
        }
    }

    private void spawnWave(ServerLevel level, BlockPos pos, int wave, RandomSource random) {
        int count = 2 + wave * 2;
        for (int i = 0; i < count; i++) {
            Mob mob = (wave >= 2 && i % 3 == 0 ? ModEntities.HOLLOW_STALKER.get() : ModEntities.SHARDLING.get()).create(level);
            place(level, pos, mob, random);
        }
        if (wave == 4) place(level, pos, ModEntities.ECHO_GUARDIAN.get().create(level), random);
        level.playSound(null, pos, SoundEvents.WARDEN_EMERGE, SoundSource.HOSTILE, 3.0F, 0.8F);
    }

    private void place(ServerLevel level, BlockPos pos, Mob mob, RandomSource random) {
        if (mob == null) return;
        double a = random.nextDouble() * Math.PI * 2.0D;
        double r = 6.0D + random.nextDouble() * 4.0D;
        mob.moveTo(pos.getX() + 0.5D + Math.cos(a) * r, pos.getY() + 1.0D, pos.getZ() + 0.5D + Math.sin(a) * r, random.nextFloat() * 360.0F, 0.0F);
        mob.addTag(TAG);
        mob.setPersistenceRequired();
        mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.TRIGGERED, null, null);
        level.addFreshEntity(mob);
    }

    private void reward(ServerLevel level, BlockPos pos, RandomSource random) {
        Vec3 c = Vec3.atCenterOf(pos.above());
        drop(level, c, new ItemStack(ModItems.ECHO_CRYSTAL.get(), 6 + random.nextInt(5)));
        drop(level, c, new ItemStack(ModItems.STARDUST.get(), 4 + random.nextInt(5)));
        drop(level, c, new ItemStack(ModItems.LUMINA_GEM.get(), 1 + random.nextInt(2)));
        drop(level, c, new ItemStack(ModItems.CANDIED_SHARD.get(), 2 + random.nextInt(3)));
        drop(level, c, new ItemStack(ModItems.ECHO_BLOOM_SEEDS.get(), 3 + random.nextInt(4)));
        if (random.nextInt(4) == 0) drop(level, c, new ItemStack(ModItems.RESONITE_TEMPLATE.get()));
        ExperienceOrb.award(level, c, 250);
        level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, c.x, c.y + 0.5D, c.z, 80, 0.6D, 0.6D, 0.6D, 0.3D);
        level.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.BLOCKS, 2.0F, 1.0F);
    }

    private void drop(ServerLevel level, Vec3 c, ItemStack stack) {
        level.addFreshEntity(new ItemEntity(level, c.x, c.y, c.z, stack));
    }
}
