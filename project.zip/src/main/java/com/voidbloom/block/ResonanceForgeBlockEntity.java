package com.voidbloom.block;

import com.voidbloom.menu.ResonanceForgeMenu;
import com.voidbloom.registry.ModBlockEntities;
import com.voidbloom.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Слоты: 0 скорчит, 1 умбралит, 2 люмина, 3 топливо, 4 результат. */
public class ResonanceForgeBlockEntity extends BlockEntity implements Container, ExtendedScreenHandlerFactory {
    public static final int SLOTS = 5;
    public static final int COOK_TIME = 600;

    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
    private int progress;
    private int burn;
    private int burnTotal;
    private boolean valid;
    private int checkTimer;

    public final ContainerData data = new ContainerData() {
        @Override
        public int get(int i) {
            return switch (i) {
                case 0 -> progress;
                case 1 -> COOK_TIME;
                case 2 -> burn;
                case 3 -> burnTotal;
                default -> valid ? 1 : 0;
            };
        }

        @Override
        public void set(int i, int v) {
            switch (i) {
                case 0 -> progress = v;
                case 2 -> burn = v;
                case 3 -> burnTotal = v;
                default -> { }
            }
        }

        @Override
        public int getCount() {
            return 5;
        }
    };

    public ResonanceForgeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.RESONANCE_FORGE.get(), pos, state);
    }

    public void recheck() {
        if (level != null) valid = ResonanceForgeBlock.countMistakes(level, worldPosition) == 0;
        checkTimer = 20;
    }

    private boolean canWork() {
        if (items.get(0).isEmpty() || items.get(1).isEmpty() || items.get(2).isEmpty()) return false;
        ItemStack out = items.get(4);
        return out.isEmpty() || (out.is(ModItems.RESONITE_INGOT.get()) && out.getCount() < out.getMaxStackSize());
    }

    public static int fuelValue(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        Integer v = FuelRegistry.INSTANCE.get(stack.getItem());
        return v == null ? 0 : v;
    }

    public static void tick(Level level, BlockPos pos, BlockState state, ResonanceForgeBlockEntity be) {
        if (--be.checkTimer <= 0) be.recheck();
        boolean changed = false;
        if (be.valid && be.canWork()) {
            if (be.burn <= 0) {
                ItemStack fuel = be.items.get(3);
                int value = fuelValue(fuel);
                if (value > 0) {
                    be.burn = value;
                    be.burnTotal = value;
                    ItemStack remainder = fuel.getItem().hasCraftingRemainingItem() ? new ItemStack(fuel.getItem().getCraftingRemainingItem()) : ItemStack.EMPTY;
                    if (fuel.getCount() == 1) be.items.set(3, remainder);
                    else fuel.shrink(1);
                    changed = true;
                }
            }
            if (be.burn > 0) {
                be.burn--;
                be.progress++;
                changed = true;
                if (level instanceof ServerLevel sl && be.progress % 8 == 0) {
                    sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, pos.getX() + 0.5D, pos.getY() + 1.1D, pos.getZ() + 0.5D, 2, 0.25D, 0.1D, 0.25D, 0.01D);
                }
                if (be.progress >= COOK_TIME) {
                    be.progress = 0;
                    for (int i = 0; i < 3; i++) be.items.get(i).shrink(1);
                    ItemStack out = be.items.get(4);
                    if (out.isEmpty()) be.items.set(4, new ItemStack(ModItems.RESONITE_INGOT.get()));
                    else out.grow(1);
                }
            }
        } else if (be.progress > 0) {
            be.progress = Math.max(0, be.progress - 2);
            changed = true;
        }
        if (changed) be.setChanged();
    }

    // --- NBT ---
    @Override
    public void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, items);
        tag.putInt("Progress", progress);
        tag.putInt("Burn", burn);
        tag.putInt("BurnTotal", burnTotal);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        items.clear();
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, items);
        progress = tag.getInt("Progress");
        burn = tag.getInt("Burn");
        burnTotal = tag.getInt("BurnTotal");
    }

    // --- Container ---
    @Override
    public int getContainerSize() {
        return SLOTS;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack s : items) if (!s.isEmpty()) return false;
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack r = ContainerHelper.removeItem(items, slot, amount);
        if (!r.isEmpty()) setChanged();
        return r;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) stack.setCount(getMaxStackSize());
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void clearContent() {
        items.clear();
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
    }

    // --- MenuProvider ---
    @Override
    public Component getDisplayName() {
        return Component.translatable("container.voidbloom.resonance_forge");
    }

    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new ResonanceForgeMenu(id, inv, this, data, ContainerLevelAccess.create(level, worldPosition));
    }

    @Override
    public void writeScreenOpeningData(ServerPlayer player, FriendlyByteBuf buf) {
        buf.writeBlockPos(worldPosition);
    }
}
