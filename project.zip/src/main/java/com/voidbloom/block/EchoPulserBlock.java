package com.voidbloom.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

/** Эхо-метроном: сам даёт импульсы редстоуна. ПКМ меняет период (0.5 / 1 / 2 / 4 с). Сигнал на блок его останавливает. */
public class EchoPulserBlock extends Block {
    public static final IntegerProperty INTERVAL = IntegerProperty.create("interval", 0, 3);
    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;
    private static final int[] TICKS = {10, 20, 40, 80};

    public EchoPulserBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(INTERVAL, 1).setValue(POWERED, false));
    }


    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(INTERVAL, POWERED);
    }

    @Override
    public boolean isSignalSource(BlockState state) {
        return true;
    }

    @Override
    public int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction dir) {
        return state.getValue(POWERED) ? 15 : 0;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide && !old.is(state.getBlock())) level.scheduleTick(pos, this, TICKS[state.getValue(INTERVAL)]);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(POWERED)) {
            level.setBlock(pos, state.setValue(POWERED, false), 3);
            level.updateNeighborsAt(pos, this);
            level.scheduleTick(pos, this, TICKS[state.getValue(INTERVAL)]);
        } else if (level.hasNeighborSignal(pos)) {
            level.scheduleTick(pos, this, 10);
        } else {
            level.setBlock(pos, state.setValue(POWERED, true), 3);
            level.updateNeighborsAt(pos, this);
            level.scheduleTick(pos, this, 2);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, net.minecraft.world.InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        int next = (state.getValue(INTERVAL) + 1) % 4;
        level.setBlock(pos, state.setValue(INTERVAL, next), 3);
        player.displayClientMessage(Component.translatable("message.voidbloom.pulser_interval", TICKS[next] / 20.0D), true);
        return InteractionResult.CONSUME;
    }
}
