package com.voidbloom.block;

import com.voidbloom.registry.ModBlockEntities;
import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Горн резонанса — контроллер мультиблока с интерфейсом (как варочная стойка).
 * Схема: куб 3x3x3 из эхо-кирпичей, в центре магма-блок, горн — вместо кирпича в середине боковой стороны среднего слоя.
 */
public class ResonanceForgeBlock extends Block implements EntityBlock {

    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final BooleanProperty ASSEMBLED = BooleanProperty.create("assembled");
    /** Пока идёт сборка/разборка куба, события удаления блоков игнорируются. */
    static boolean busy = false;

    public ResonanceForgeBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(ASSEMBLED, false));
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, ASSEMBLED);
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean moved) {
        super.onPlace(state, level, pos, oldState, moved);
        if (!level.isClientSide && !oldState.is(state.getBlock())) tryAssemble(level, pos);
    }

    private static boolean cellOk(Level level, BlockPos p, boolean centerCell) {
        BlockState bs = level.getBlockState(p);
        if (bs.is(ModBlocks.RESONANCE_HULL.get())) return true;
        return bs.is(centerCell ? Blocks.MAGMA_BLOCK : ModBlocks.ECHO_BRICKS.get());
    }

    private static int mistakes(Level level, BlockPos core, Direction dir) {
        BlockPos center = core.relative(dir);
        int bad = 0;
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                for (int dz = -1; dz <= 1; dz++) {
                    BlockPos p = center.offset(dx, dy, dz);
                    if (p.equals(core)) continue;
                    if (!cellOk(level, p, dx == 0 && dy == 0 && dz == 0)) bad++;
                }
        return bad;
    }

    /** Когда куб собран верно, все 26 блоков превращаются в один цельный большой блок. */
    public static boolean tryAssemble(Level level, BlockPos core) {
        BlockState fs = level.getBlockState(core);
        if (!fs.is(ModBlocks.RESONANCE_FORGE.get()) || fs.getValue(ASSEMBLED)) return false;
        Direction found = null;
        for (Direction d : Direction.Plane.HORIZONTAL) if (mistakes(level, core, d) == 0) { found = d; break; }
        if (found == null) return false;
        BlockPos center = core.relative(found);
        busy = true;
        try {
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos p = center.offset(dx, dy, dz);
                        if (p.equals(core)) continue;
                        level.setBlock(p, ModBlocks.RESONANCE_HULL.get().defaultBlockState()
                                .setValue(ResonanceHullBlock.CX, dx + 1).setValue(ResonanceHullBlock.CY, dy + 1)
                                .setValue(ResonanceHullBlock.CZ, dz + 1), 3);
                    }
            level.setBlock(core, fs.setValue(ASSEMBLED, true).setValue(FACING, found.getOpposite()), 3);
        } finally {
            busy = false;
        }
        level.playSound(null, center, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.2F);
        return true;
    }

    /** Ломается часть собранного куба: всё снова становится кирпичами и магмой. */
    public static void disassemble(Level level, BlockPos center, BlockPos except) {
        busy = true;
        try {
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos p = center.offset(dx, dy, dz);
                        if (p.equals(except)) continue;
                        BlockState bs = level.getBlockState(p);
                        if (bs.is(ModBlocks.RESONANCE_HULL.get())) {
                            level.setBlock(p, (dx == 0 && dy == 0 && dz == 0 ? Blocks.MAGMA_BLOCK : ModBlocks.ECHO_BRICKS.get()).defaultBlockState(), 3);
                        } else if (bs.is(ModBlocks.RESONANCE_FORGE.get()) && bs.getValue(ASSEMBLED)) {
                            level.setBlock(p, bs.setValue(ASSEMBLED, false), 3);
                        }
                    }
        } finally {
            busy = false;
        }
    }


    /**
     * Куб 3x3x3 из эхо-кирпичей: в середине магма-блок, а горн заменяет один из кирпичей
     * в середине любой боковой стороны среднего слоя. Возвращает наименьшее число ошибок
     * среди четырёх возможных положений горна.
     */
    public static int countMistakes(Level level, BlockPos core) {
        int best = Integer.MAX_VALUE;
        for (Direction dir : Direction.Plane.HORIZONTAL) best = Math.min(best, mistakes(level, core, dir));
        return best;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, net.minecraft.world.InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        int bad = countMistakes(level, pos);
        if (bad > 0) {
            player.displayClientMessage(Component.translatable("message.voidbloom.forge_bad", bad), true);
            return InteractionResult.CONSUME;
        }
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof ResonanceForgeBlockEntity forge && player instanceof ServerPlayer sp) {
            forge.recheck();
            sp.openMenu(forge);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ResonanceForgeBlockEntity(pos, state);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide || type != ModBlockEntities.RESONANCE_FORGE.get()) return null;
        return (BlockEntityTicker<T>) (BlockEntityTicker<ResonanceForgeBlockEntity>) ResonanceForgeBlockEntity::tick;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock())) {
            if (!level.isClientSide && !busy && state.getValue(ASSEMBLED)) {
                disassemble(level, pos.relative(state.getValue(FACING).getOpposite()), pos);
            }
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof ResonanceForgeBlockEntity forge) {
                Containers.dropContents(level, pos, forge);
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
