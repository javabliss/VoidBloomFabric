package com.voidbloom.block;

import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/** Поиск рамки, зажигание портала и создание портала на другой стороне. */
public final class PortalHelper {
    private static final int MAX_SIZE = 21;

    private PortalHelper() {}

    private static boolean isFrame(BlockState s) {
        return s.is(ModBlocks.RIFT_FRAME.get());
    }

    private static boolean isEmpty(BlockState s) {
        return s.isAir() || s.is(net.minecraft.tags.BlockTags.FIRE);
    }

    /** Пытается зажечь портал рядом с start (блок, соседний с рамкой). */
    public static boolean tryLight(Level level, BlockPos start) {
        return tryLight(level, start, Direction.Axis.X) || tryLight(level, start, Direction.Axis.Z);
    }

    private static boolean tryLight(Level level, BlockPos start, Direction.Axis axis) {
        Direction right = axis == Direction.Axis.X ? Direction.EAST : Direction.SOUTH;
        Direction left = right.getOpposite();

        BlockPos p = start;
        int guard = 0;
        while (isEmpty(level.getBlockState(p.below())) && guard++ < MAX_SIZE) p = p.below();
        if (!isEmpty(level.getBlockState(p)) || !isFrame(level.getBlockState(p.below()))) return false;

        guard = 0;
        while (isEmpty(level.getBlockState(p.relative(left))) && guard++ < MAX_SIZE) p = p.relative(left);
        if (!isFrame(level.getBlockState(p.relative(left)))) return false;

        int width = 0;
        while (width <= MAX_SIZE && isEmpty(level.getBlockState(p.relative(right, width)))) {
            if (!isFrame(level.getBlockState(p.relative(right, width).below()))) return false;
            width++;
        }
        if (width < 2 || width > MAX_SIZE || !isFrame(level.getBlockState(p.relative(right, width)))) return false;

        int height = 0;
        while (height <= MAX_SIZE) {
            if (!isFrame(level.getBlockState(p.relative(left).above(height)))
                    || !isFrame(level.getBlockState(p.relative(right, width).above(height)))) break;
            boolean rowEmpty = true;
            for (int i = 0; i < width; i++) {
                if (!isEmpty(level.getBlockState(p.relative(right, i).above(height)))) {
                    rowEmpty = false;
                    break;
                }
            }
            if (!rowEmpty) break;
            height++;
        }
        if (height < 3 || height > MAX_SIZE) return false;
        for (int i = 0; i < width; i++) {
            if (!isFrame(level.getBlockState(p.relative(right, i).above(height)))) return false;
        }

        BlockState portal = ModBlocks.RIFT_PORTAL.get().defaultBlockState().setValue(RiftPortalBlock.AXIS, axis);
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                level.setBlock(p.relative(right, i).above(j), portal, 18);
            }
        }
        return true;
    }

    /** Ищет существующий портал рядом с точкой или строит новый. Возвращает позицию, куда ставить сущность. */
    public static BlockPos findOrCreate(ServerLevel dest, BlockPos src, boolean toEchoExpanse) {
        int x = src.getX();
        int z = src.getZ();
        dest.getChunk(x >> 4, z >> 4);

        // Оба направления: строим на поверхности (чанк уже сгенерирован строкой выше).
        int y = Math.max(dest.getMinBuildHeight() + 5, dest.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z));

        BlockPos base = new BlockPos(x, y, z);
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                for (int dy = -6; dy <= 8; dy++) {
                    BlockPos q = base.offset(dx, dy, dz);
                    BlockState s = dest.getBlockState(q);
                    if (s.is(ModBlocks.RIFT_PORTAL.get())) {
                        return standNextTo(dest, q, s.getValue(RiftPortalBlock.AXIS));
                    }
                }
            }
        }
        buildPortal(dest, base, toEchoExpanse);
        return standNextTo(dest, base, Direction.Axis.X);
    }

    private static BlockPos standNextTo(ServerLevel level, BlockPos portalPos, Direction.Axis axis) {
        Direction normal = axis == Direction.Axis.X ? Direction.SOUTH : Direction.EAST;
        for (Direction d : new Direction[]{normal, normal.getOpposite()}) {
            BlockPos c = portalPos.relative(d, 2);
            if (level.getBlockState(c).isAir() && level.getBlockState(c.above()).isAir()
                    && !level.getBlockState(c.below()).isAir()) {
                return c;
            }
        }
        return portalPos.relative(normal, 2);
    }

    /** Площадка 7x7, рамка 4x5 и проём 2x3. origin — нижний левый блок проёма (ось X). */
    private static void buildPortal(ServerLevel level, BlockPos origin, boolean toEchoExpanse) {
        BlockState floor = toEchoExpanse ? ModBlocks.ECHO_STONE.get().defaultBlockState()
                : Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        for (int dx = -3; dx <= 4; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                level.setBlock(origin.offset(dx, -1, dz), floor, 3);
                for (int dy = 0; dy <= 5; dy++) {
                    level.setBlock(origin.offset(dx, dy, dz), Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
        BlockState frame = ModBlocks.RIFT_FRAME.get().defaultBlockState();
        for (int i = -1; i <= 2; i++) {
            level.setBlock(origin.offset(i, -1, 0), frame, 3);
            level.setBlock(origin.offset(i, 3, 0), frame, 3);
        }
        for (int j = 0; j <= 2; j++) {
            level.setBlock(origin.offset(-1, j, 0), frame, 3);
            level.setBlock(origin.offset(2, j, 0), frame, 3);
        }
        BlockState portal = ModBlocks.RIFT_PORTAL.get().defaultBlockState()
                .setValue(RiftPortalBlock.AXIS, Direction.Axis.X);
        for (int i = 0; i <= 1; i++) {
            for (int j = 0; j <= 2; j++) {
                level.setBlock(origin.offset(i, j, 0), portal, 18);
            }
        }
    }
}
