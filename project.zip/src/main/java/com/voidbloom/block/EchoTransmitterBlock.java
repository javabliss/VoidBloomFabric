package com.voidbloom.block;

import net.minecraft.world.level.block.Block;

public class EchoTransmitterBlock extends EchoWirelessBlock {

    public EchoTransmitterBlock(Properties properties) {
        super(properties, false);
    }

}
