package com.voidbloom.block;

import net.minecraft.world.level.block.Block;

public class EchoReceiverBlock extends EchoWirelessBlock {

    public EchoReceiverBlock(Properties properties) {
        super(properties, true);
    }

}
