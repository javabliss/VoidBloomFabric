package com.voidbloom.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Беспроводная пара: передатчик (получает редстоун) и приёмник (выдаёт редстоун).
 * Работают на одной частоте 1–8 (ПКМ меняет), дальность 128 блоков, в пределах одного измерения.
 */
public abstract class EchoWirelessBlock extends Block {
    public static final IntegerProperty FREQ = IntegerProperty.create("freq", 1, 8);
    public static final BooleanProperty LIT = BooleanProperty.create("lit");
    private static final Map<Level, Map<Long, Integer>> ACTIVE = new WeakHashMap<>();

    private final boolean receiver;

    protected EchoWirelessBlock(Properties properties, boolean receiver) {
        super(properties);
        this.receiver = receiver;
        registerDefaultState(stateDefinition.any().setValue(FREQ, 1).setValue(LIT, false));
    }

    private static Map<Long, Integer> active(Level level) {
        return ACTIVE.computeIfAbsent(level, k -> new HashMap<>());
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FREQ, LIT);
    }

    @Override
    public boolean isSignalSource(BlockState state) {
        return receiver;
    }

    @Override
    public int getSignal(BlockState state, BlockGetter level, BlockPos pos, Direction dir) {
        return receiver && state.getValue(LIT) ? 15 : 0;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide && !old.is(state.getBlock())) level.scheduleTick(pos, this, 4);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!level.isClientSide && !state.is(newState.getBlock())) active(level).remove(pos.asLong());
        super.onRemove(state, level, pos, newState, moved);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        boolean on;
        if (receiver) {
            on = false;
            int f = state.getValue(FREQ);
            for (Map.Entry<Long, Integer> e : active(level).entrySet()) {
                if (e.getValue() == f && BlockPos.of(e.getKey()).distSqr(pos) <= 128.0D * 128.0D) {
                    on = true;
                    break;
                }
            }
        } else {
            on = level.hasNeighborSignal(pos);
            if (on) active(level).put(pos.asLong(), state.getValue(FREQ));
            else active(level).remove(pos.asLong());
        }
        if (on != state.getValue(LIT)) {
            level.setBlock(pos, state.setValue(LIT, on), 3);
            if (receiver) level.updateNeighborsAt(pos, this);
        }
        level.scheduleTick(pos, this, 4);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, net.minecraft.world.InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        int next = state.getValue(FREQ) % 8 + 1;
        level.setBlock(pos, state.setValue(FREQ, next), 3);
        player.displayClientMessage(Component.translatable("message.voidbloom.wireless_freq", next), true);
        return InteractionResult.CONSUME;
    }
}
