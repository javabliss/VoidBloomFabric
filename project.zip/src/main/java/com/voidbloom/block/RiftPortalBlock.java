package com.voidbloom.block;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.portal.PortalInfo;
import net.fabricmc.fabric.api.dimension.v1.FabricDimensions;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class RiftPortalBlock extends Block {
    public static final EnumProperty<Direction.Axis> AXIS = BlockStateProperties.HORIZONTAL_AXIS;

    private static final VoxelShape X_SHAPE = Block.box(0.0D, 0.0D, 6.0D, 16.0D, 16.0D, 10.0D);
    private static final VoxelShape Z_SHAPE = Block.box(6.0D, 0.0D, 0.0D, 10.0D, 16.0D, 16.0D);

    public RiftPortalBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(AXIS, Direction.Axis.X));
    }


    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return state.getValue(AXIS) == Direction.Axis.X ? X_SHAPE : Z_SHAPE;
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AXIS);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction facing, BlockState facingState,
                                     LevelAccessor level, BlockPos pos, BlockPos facingPos) {
        Direction.Axis own = state.getValue(AXIS);
        Direction.Axis changed = facing.getAxis();
        // Нас интересуют только соседи в плоскости портала (вертикаль и своя горизонтальная ось).
        boolean inPlane = changed == Direction.Axis.Y || changed == own;
        if (inPlane && !facingState.is(this) && !facingState.is(ModBlocks.RIFT_FRAME.get())) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, facing, facingState, level, pos, facingPos);
    }

    private static final Map<UUID, long[]> TIMERS = new HashMap<>(); // [начало контакта, последний контакт, кулдаун до]

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(level instanceof ServerLevel server) || !entity.canChangeDimensions()
                || entity.isPassenger() || entity.isVehicle()) return;
        long now = server.getGameTime();
        long[] t = TIMERS.computeIfAbsent(entity.getUUID(), k -> new long[]{now, now, 0});
        if (now < t[2]) {
            t[1] = now;
            return;
        }
        if (now - t[1] > 3) t[0] = now;
        t[1] = now;
        int wait = entity instanceof Player ? 60 : 0;
        if (now - t[0] < wait) return;

        ResourceKey<Level> targetKey = server.dimension() == VoidbloomMod.ECHO_EXPANSE ? Level.OVERWORLD : VoidbloomMod.ECHO_EXPANSE;
        ServerLevel dest = server.getServer().getLevel(targetKey);
        if (dest == null) return;
        BlockPos stand = PortalHelper.findOrCreate(dest, pos, targetKey == VoidbloomMod.ECHO_EXPANSE);
        t[2] = now + 100;
        t[0] = now;
        FabricDimensions.teleport(entity, dest, new PortalInfo(Vec3.atBottomCenterOf(stand), Vec3.ZERO, entity.getYRot(), entity.getXRot()));
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(100) == 0) {
            level.playLocalSound(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                    net.minecraft.sounds.SoundEvents.PORTAL_AMBIENT, net.minecraft.sounds.SoundSource.BLOCKS,
                    0.5F, random.nextFloat() * 0.4F + 0.8F, false);
        }
        for (int i = 0; i < 2; i++) {
            level.addParticle(ParticleTypes.REVERSE_PORTAL,
                    pos.getX() + random.nextDouble(), pos.getY() + random.nextDouble(), pos.getZ() + random.nextDouble(),
                    (random.nextDouble() - 0.5D) * 0.2D, random.nextDouble() * 0.2D, (random.nextDouble() - 0.5D) * 0.2D);
        }
    }

    @Override
    public boolean skipRendering(BlockState state, BlockState adjacent, Direction dir) {
        return adjacent.is(this);
    }

    @Override
    public net.minecraft.world.item.ItemStack getCloneItemStack(net.minecraft.world.level.BlockGetter level, BlockPos pos, BlockState state) {
        return net.minecraft.world.item.ItemStack.EMPTY;
    }
}
