package com.voidbloom.client;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.menu.ResonanceForgeMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class ResonanceForgeScreen extends AbstractContainerScreen<ResonanceForgeMenu> {
    private static final ResourceLocation TEX = VoidbloomMod.id("textures/gui/resonance_forge.png");

    public ResonanceForgeScreen(ResonanceForgeMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        g.blit(TEX, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        int burn = menu.burnScaled(13);
        if (burn > 0) g.blit(TEX, leftPos + 53, topPos + 36 + 14 - burn, 176, 17 + 14 - burn, 14, burn);
        int prog = menu.progressScaled(24);
        if (prog > 0) g.blit(TEX, leftPos + 103, topPos + 35, 176, 0, prog, 17);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        super.renderLabels(g, mouseX, mouseY);
        if (!menu.isValidStructure()) {
            g.drawString(this.font, Component.translatable("gui.voidbloom.forge_invalid"), 90, 58, 0xFF5555, false);
        }
    }
}
