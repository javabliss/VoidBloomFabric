package com.voidbloom.client;

import com.voidbloom.registry.ModBlocks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.client.renderer.RenderType;

public class VoidbloomClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderType.cutout(),
                ModBlocks.ECHO_DOOR.get(), ModBlocks.ECHO_TRAPDOOR.get(), ModBlocks.ECHO_BLOOM.get());
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderType.cutoutMipped(), ModBlocks.VOID_LEAVES.get());
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderType.translucent(),
                ModBlocks.ECHO_GLASS.get(), ModBlocks.RIFT_PORTAL.get(), ModBlocks.ECHO_JELLY.get());
        ClientSetup.register();
    }
}
