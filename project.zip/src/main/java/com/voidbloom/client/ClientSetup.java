package com.voidbloom.client;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.client.model.DrifterModel;
import com.voidbloom.client.model.GuardianModel;
import com.voidbloom.client.model.PuffModel;
import com.voidbloom.client.model.ShardlingModel;
import com.voidbloom.client.model.SovereignModel;
import com.voidbloom.client.model.StalkerModel;
import com.voidbloom.entity.EchoDrifterEntity;
import com.voidbloom.entity.EchoGuardianEntity;
import com.voidbloom.entity.EchoSovereignEntity;
import com.voidbloom.entity.GlowPuffEntity;
import com.voidbloom.entity.HollowStalkerEntity;
import com.voidbloom.entity.ShardlingEntity;
import com.voidbloom.registry.ModEntities;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
public class ClientSetup {

    public static void register() {
        DimensionRenderingRegistry.registerDimensionEffects(VoidbloomMod.id("echo_sky"), new EchoSkyEffects());
        DimensionRenderingRegistry.registerSkyRenderer(VoidbloomMod.ECHO_EXPANSE, EchoSkyEffects::renderSky);
        MenuScreens.register(com.voidbloom.registry.ModMenus.RESONANCE_FORGE.get(), ResonanceForgeScreen::new);

        EntityModelLayerRegistry.registerModelLayer(ShardlingModel.LAYER, ShardlingModel::createLayer);
        EntityModelLayerRegistry.registerModelLayer(StalkerModel.LAYER, StalkerModel::createLayer);
        EntityModelLayerRegistry.registerModelLayer(PuffModel.LAYER, PuffModel::createLayer);
        EntityModelLayerRegistry.registerModelLayer(SovereignModel.LAYER, SovereignModel::createLayer);
        EntityModelLayerRegistry.registerModelLayer(DrifterModel.LAYER, DrifterModel::createLayer);
        EntityModelLayerRegistry.registerModelLayer(GuardianModel.LAYER, GuardianModel::createLayer);

        EntityRendererRegistry.register(ModEntities.SHARDLING.get(), GenericMobRenderer.<ShardlingEntity, ShardlingModel<ShardlingEntity>>of(
                ShardlingModel::new, ShardlingModel.LAYER, 0.4F, "shardling", 1.15F));
        EntityRendererRegistry.register(ModEntities.HOLLOW_STALKER.get(), GenericMobRenderer.<HollowStalkerEntity, StalkerModel<HollowStalkerEntity>>of(
                StalkerModel::new, StalkerModel.LAYER, 0.5F, "hollow_stalker", 1.15F));
        EntityRendererRegistry.register(ModEntities.GLOW_PUFF.get(), GenericMobRenderer.<GlowPuffEntity, PuffModel<GlowPuffEntity>>of(
                PuffModel::new, PuffModel.LAYER, 0.5F, "glow_puff", 1.2F));
        EntityRendererRegistry.register(ModEntities.ECHO_SOVEREIGN.get(), GenericMobRenderer.<EchoSovereignEntity, SovereignModel<EchoSovereignEntity>>of(
                SovereignModel::new, SovereignModel.LAYER, 1.2F, "echo_sovereign", 1.05F));
        EntityRendererRegistry.register(ModEntities.ECHO_DRIFTER.get(), GenericMobRenderer.<EchoDrifterEntity, DrifterModel<EchoDrifterEntity>>of(
                DrifterModel::new, DrifterModel.LAYER, 0.3F, "echo_drifter", 1.0F));
        EntityRendererRegistry.register(ModEntities.ECHO_GUARDIAN.get(), GenericMobRenderer.<EchoGuardianEntity, GuardianModel<EchoGuardianEntity>>of(
                GuardianModel::new, GuardianModel.LAYER, 0.8F, "echo_guardian", 1.35F));
        EntityRendererRegistry.register(ModEntities.ECHO_VILLAGER.get(), EchoVillagerRenderer::new);

        ClientHooks.register();
        TooltipEvents.register();
    }

    private static ResourceLocation tex(String name) {
        return VoidbloomMod.id("textures/entity/" + name + ".png");
    }

    static class EchoVillagerRenderer extends net.minecraft.client.renderer.entity.VillagerRenderer {
        EchoVillagerRenderer(EntityRendererProvider.Context ctx) {
            super(ctx);
        }

        @Override
        public ResourceLocation getTextureLocation(net.minecraft.world.entity.npc.Villager villager) {
            return tex("echo_villager");
        }
    }
}
