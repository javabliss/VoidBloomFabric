package com.voidbloom.client;

import com.voidbloom.net.GatePayloads;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.network.FriendlyByteBuf;

import java.util.List;

/** Экран эхо-врат: список врат, переименование и телепорт. */
public class WaypointScreen extends Screen {
    private static final int W = 236, H = 206, ROWS = 6;

    private GatePayloads.Open data;
    private int selected = -1;
    private int page = 0;
    private String pendingName = "";
    private EditBox nameBox;
    private Button renameBtn, tpBtn;
    private int left, top;

    public WaypointScreen(GatePayloads.Open data) {
        super(Component.translatable("gui.voidbloom.gate_title"));
        this.data = data;
        for (int i = 0; i < data.gates().size(); i++) {
            if (isCurrent(data.gates().get(i))) selected = i;
        }
        if (selected >= 0) pendingName = data.gates().get(selected).name();
    }

    public void update(GatePayloads.Open payload) {
        GatePayloads.Entry old = selected >= 0 && selected < data.gates().size() ? data.gates().get(selected) : null;
        this.data = payload;
        selected = -1;
        if (old != null) {
            for (int i = 0; i < payload.gates().size(); i++) {
                GatePayloads.Entry e = payload.gates().get(i);
                if (e.pos().equals(old.pos()) && e.dim().equals(old.dim())) selected = i;
            }
        }
        pendingName = selected >= 0 ? payload.gates().get(selected).name() : "";
        rebuildWidgets();
    }

    private boolean isCurrent(GatePayloads.Entry e) {
        return e.pos().equals(data.current()) && e.dim().equals(data.dim());
    }

    private static String shortDim(String dim) {
        String s = dim.contains(":") ? dim.substring(dim.indexOf(':') + 1) : dim;
        return s.replace('_', ' ');
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
        List<GatePayloads.Entry> list = data.gates();
        int pages = Math.max(1, (list.size() + ROWS - 1) / ROWS);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= list.size()) break;
            GatePayloads.Entry e = list.get(idx);
            String label = (isCurrent(e) ? "★ " : "") + e.name() + "  §7(" + shortDim(e.dim()) + ")";
            final int index = idx;
            Button b = Button.builder(Component.literal(label), btn -> select(index))
                    .bounds(left + 10, top + 22 + i * 19, W - 20, 18).build();
            b.active = index != selected;
            addRenderableWidget(b);
        }
        addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            page--;
            rebuildWidgets();
        }).bounds(left + 10, top + 138, 20, 16).build()).active = page > 0;
        addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            page++;
            rebuildWidgets();
        }).bounds(left + W - 30, top + 138, 20, 16).build()).active = page < pages - 1;

        nameBox = new EditBox(font, left + 10, top + 158, 120, 18, Component.empty());
        nameBox.setMaxLength(24);
        nameBox.setValue(pendingName);
        addRenderableWidget(nameBox);
        renameBtn = addRenderableWidget(Button.builder(Component.translatable("gui.voidbloom.gate_rename"), b -> rename())
                .bounds(left + 134, top + 158, W - 144, 18).build());
        tpBtn = addRenderableWidget(Button.builder(Component.translatable("gui.voidbloom.gate_teleport"), b -> teleport())
                .bounds(left + 10, top + 180, W - 20, 18).build());
        refreshButtons();
    }

    private void select(int index) {
        pendingName = nameBox != null ? nameBox.getValue() : pendingName;
        selected = index;
        pendingName = data.gates().get(index).name();
        rebuildWidgets();
    }

    private void refreshButtons() {
        boolean has = selected >= 0 && selected < data.gates().size();
        renameBtn.active = has && data.canEdit();
        nameBox.setEditable(has && data.canEdit());
        tpBtn.active = has && !isCurrent(data.gates().get(selected));
    }

    private static void send(GatePayloads.Action a) {
        FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
        GatePayloads.Action.write(buf, a);
        ClientPlayNetworking.send(GatePayloads.Action.ID, buf);
    }

    private void rename() {
        if (selected < 0) return;
        GatePayloads.Entry e = data.gates().get(selected);
        send(new GatePayloads.Action(0, data.current(), e.pos(), e.dim(), nameBox.getValue()));
    }

    private void teleport() {
        if (selected < 0) return;
        GatePayloads.Entry e = data.gates().get(selected);
        send(new GatePayloads.Action(1, data.current(), e.pos(), e.dim(), ""));
        onClose();
    }

    @Override
    public void renderBackground(GuiGraphics g) {
        super.renderBackground(g);
        g.fill(left, top, left + W, top + H, 0xE6120C24);
        g.renderOutline(left, top, W, H, 0xFF7FF0E6);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(font, title, width / 2, top + 8, 0xFF8FC3);
        int pages = Math.max(1, (data.gates().size() + ROWS - 1) / ROWS);
        g.drawCenteredString(font, (page + 1) + " / " + pages, width / 2, top + 142, 0xBBBBBB);
        if (!data.canEdit()) {
            g.drawCenteredString(font, Component.translatable("gui.voidbloom.gate_readonly"), width / 2, top + 126, 0xAA7777);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
