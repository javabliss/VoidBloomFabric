package com.voidbloom.client;

import com.voidbloom.VoidbloomMod;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.ChatFormatting;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/** Подсказки на предметах мода: ключ tooltip.voidbloom.<имя>. */
public class TooltipEvents {
    public static void register() {
        ItemTooltipCallback.EVENT.register((stack, flag, lines) -> {
            ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
            if (!id.getNamespace().equals(VoidbloomMod.MODID)) return;
            String path = id.getPath();
            if (path.matches("(echo|resonite)_(helmet|chestplate|leggings|boots)")) path = path.substring(0, path.indexOf('_')) + "_armor";
            String key = "tooltip.voidbloom." + path;
            if (I18n.exists(key)) lines.add(Component.translatable(key).withStyle(ChatFormatting.GRAY));
        });
    }
}
