package com.voidbloom.client;

import com.voidbloom.net.GatePayloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;

/** Клиентские обработчики пакетов. */
public class ClientHooks {
    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(GatePayloads.Open.ID, (client, handler, buf, sender) -> {
            GatePayloads.Open payload = GatePayloads.Open.read(buf);
            client.execute(() -> openGateScreen(payload));
        });
    }

    public static void openGateScreen(GatePayloads.Open payload) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof WaypointScreen screen) screen.update(payload);
        else mc.setScreen(new WaypointScreen(payload));
    }
}
