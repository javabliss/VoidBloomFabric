package com.voidbloom.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/** Сгенерировано gen_v7d.py: модель «echo_guardian». */
public class GuardianModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(VoidbloomMod.id("echo_guardian"), "main");
    private final ModelPart root;
    private final ModelPart p_legR;
    private final ModelPart p_legL;
    private final ModelPart p_torso;
    private final ModelPart p_gem;
    private final ModelPart p_head;
    private final ModelPart p_hornL;
    private final ModelPart p_hornR;
    private final ModelPart p_armL;
    private final ModelPart p_fistL;
    private final ModelPart p_armR;
    private final ModelPart p_fistR;
    private final ModelPart p_bc0;
    private final ModelPart p_bc1;
    private final ModelPart p_bc2;

    public GuardianModel(ModelPart root) {
        this.root = root;
        this.p_legR = root.getChild("legR");
        this.p_legL = root.getChild("legL");
        this.p_torso = root.getChild("torso");
        this.p_gem = root.getChild("torso").getChild("gem");
        this.p_head = root.getChild("torso").getChild("head");
        this.p_hornL = root.getChild("torso").getChild("head").getChild("hornL");
        this.p_hornR = root.getChild("torso").getChild("head").getChild("hornR");
        this.p_armL = root.getChild("torso").getChild("armL");
        this.p_fistL = root.getChild("torso").getChild("armL").getChild("fistL");
        this.p_armR = root.getChild("torso").getChild("armR");
        this.p_fistR = root.getChild("torso").getChild("armR").getChild("fistR");
        this.p_bc0 = root.getChild("torso").getChild("bc0");
        this.p_bc1 = root.getChild("torso").getChild("bc1");
        this.p_bc2 = root.getChild("torso").getChild("bc2");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition d_legR = root.addOrReplaceChild("legR", CubeListBuilder.create().texOffs(0, 21).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 9.0F, 6.0F), PartPose.offsetAndRotation(-3.5F, 15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_legL = root.addOrReplaceChild("legL", CubeListBuilder.create().texOffs(24, 21).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 9.0F, 6.0F), PartPose.offsetAndRotation(3.5F, 15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_torso = root.addOrReplaceChild("torso", CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -13.0F, -4.0F, 14.0F, 13.0F, 8.0F), PartPose.offsetAndRotation(0.0F, 15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_gem = d_torso.addOrReplaceChild("gem", CubeListBuilder.create().texOffs(32, 36).addBox(-2.5F, -2.5F, -1.0F, 5.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -6.0F, -4.2F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_head = d_torso.addOrReplaceChild("head", CubeListBuilder.create().texOffs(84, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, -13.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_hornL = d_head.addOrReplaceChild("hornL", CubeListBuilder.create().texOffs(46, 36).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.5F));
        PartDefinition d_hornR = d_head.addOrReplaceChild("hornR", CubeListBuilder.create().texOffs(54, 36).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -8.0F, 0.0F, 0.0F, 0.0F, -0.5F));
        PartDefinition d_armL = d_torso.addOrReplaceChild("armL", CubeListBuilder.create().texOffs(44, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 16.0F, 5.0F), PartPose.offsetAndRotation(9.5F, -11.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_fistL = d_armL.addOrReplaceChild("fistL", CubeListBuilder.create().texOffs(48, 21).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 7.0F, 7.0F), PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_armR = d_torso.addOrReplaceChild("armR", CubeListBuilder.create().texOffs(64, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 16.0F, 5.0F), PartPose.offsetAndRotation(-9.5F, -11.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_fistR = d_armR.addOrReplaceChild("fistR", CubeListBuilder.create().texOffs(76, 21).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 7.0F, 7.0F), PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_bc0 = d_torso.addOrReplaceChild("bc0", CubeListBuilder.create().texOffs(0, 36).addBox(-2.0F, -9.0F, -2.0F, 4.0F, 9.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, -13.0F, 4.0F, 0.4F, 0.0F, -0.2F));
        PartDefinition d_bc1 = d_torso.addOrReplaceChild("bc1", CubeListBuilder.create().texOffs(16, 36).addBox(-2.0F, -9.0F, -2.0F, 4.0F, 9.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -13.0F, 4.0F, 0.4F, 0.0F, 0.2F));
        PartDefinition d_bc2 = d_torso.addOrReplaceChild("bc2", CubeListBuilder.create().texOffs(104, 21).addBox(-1.5F, -11.0F, -1.5F, 3.0F, 11.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -15.0F, 4.0F, 0.5F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        boolean aggro = entity instanceof Mob m && m.isAggressive();
        float t = age;
        p_head.yRot = yaw * 0.017453292F;
        p_head.xRot = pitch * 0.017453292F;
        float sw = Mth.cos(limbSwing * 0.6662F) * 1.1F * limbSwingAmount;
        p_legR.xRot = sw;
        p_legL.xRot = -sw;
        float armBase = aggro ? -1.1F + Mth.sin(t * 0.25F) * 0.12F : 0.0F;
        p_armR.xRot = armBase - (aggro ? 0.0F : sw * 0.8F);
        p_armL.xRot = armBase + (aggro ? 0.0F : sw * 0.8F);
        p_armR.zRot = 0.06F;
        p_armL.zRot = -0.06F;
        p_gem.xScale = p_gem.yScale = 1.0F + Mth.sin(t * 0.15F) * 0.12F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
