package com.voidbloom.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/** Сгенерировано gen_v7d.py: модель «shardling». */
public class ShardlingModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(VoidbloomMod.id("shardling"), "main");
    private final ModelPart root;
    private final ModelPart p_legR;
    private final ModelPart p_legL;
    private final ModelPart p_body;
    private final ModelPart p_head;
    private final ModelPart p_hs0;
    private final ModelPart p_hs1;
    private final ModelPart p_hs2;
    private final ModelPart p_armR;
    private final ModelPart p_armL;
    private final ModelPart p_bs0;
    private final ModelPart p_bs1;
    private final ModelPart p_bs2;

    public ShardlingModel(ModelPart root) {
        this.root = root;
        this.p_legR = root.getChild("legR");
        this.p_legL = root.getChild("legL");
        this.p_body = root.getChild("body");
        this.p_head = root.getChild("body").getChild("head");
        this.p_hs0 = root.getChild("body").getChild("head").getChild("hs0");
        this.p_hs1 = root.getChild("body").getChild("head").getChild("hs1");
        this.p_hs2 = root.getChild("body").getChild("head").getChild("hs2");
        this.p_armR = root.getChild("body").getChild("armR");
        this.p_armL = root.getChild("body").getChild("armL");
        this.p_bs0 = root.getChild("body").getChild("bs0");
        this.p_bs1 = root.getChild("body").getChild("bs1");
        this.p_bs2 = root.getChild("body").getChild("bs2");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition d_legR = root.addOrReplaceChild("legR", CubeListBuilder.create().texOffs(34, 16).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(-2.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_legL = root.addOrReplaceChild("legL", CubeListBuilder.create().texOffs(46, 16).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(2.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-3.5F, -7.0F, -2.0F, 7.0F, 7.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_head = d_body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(0.0F, -7.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_hs0 = d_head.addOrReplaceChild("hs0", CubeListBuilder.create().texOffs(0, 27).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_hs1 = d_head.addOrReplaceChild("hs1", CubeListBuilder.create().texOffs(24, 27).addBox(-1.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(-3.0F, -8.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        PartDefinition d_hs2 = d_head.addOrReplaceChild("hs2", CubeListBuilder.create().texOffs(32, 27).addBox(-1.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(3.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition d_armR = d_body.addOrReplaceChild("armR", CubeListBuilder.create().texOffs(32, 0).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 9.0F, 3.0F), PartPose.offsetAndRotation(-5.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_armL = d_body.addOrReplaceChild("armL", CubeListBuilder.create().texOffs(44, 0).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 9.0F, 3.0F), PartPose.offsetAndRotation(5.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_bs0 = d_body.addOrReplaceChild("bs0", CubeListBuilder.create().texOffs(22, 16).addBox(-1.5F, -7.0F, -1.5F, 3.0F, 7.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -8.0F, 2.0F, 0.5F, 0.0F, 0.0F));
        PartDefinition d_bs1 = d_body.addOrReplaceChild("bs1", CubeListBuilder.create().texOffs(8, 27).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -6.0F, 2.0F, 0.5F, 0.0F, -0.4F));
        PartDefinition d_bs2 = d_body.addOrReplaceChild("bs2", CubeListBuilder.create().texOffs(16, 27).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -6.0F, 2.0F, 0.5F, 0.0F, 0.4F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        boolean aggro = entity instanceof Mob m && m.isAggressive();
        float t = age;
        p_head.yRot = yaw * 0.017453292F;
        p_head.xRot = pitch * 0.017453292F;
        float sw = Mth.cos(limbSwing * 0.8F) * 1.3F * limbSwingAmount;
        p_legR.xRot = sw;
        p_legL.xRot = -sw;
        p_armR.xRot = aggro ? -1.5F + Mth.sin(t * 0.4F) * 0.2F : -sw;
        p_armL.xRot = aggro ? -1.5F - Mth.sin(t * 0.4F) * 0.2F : sw;
        p_armR.zRot = 0.1F;
        p_armL.zRot = -0.1F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
