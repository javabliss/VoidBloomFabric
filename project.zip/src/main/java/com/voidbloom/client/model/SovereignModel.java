package com.voidbloom.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/** Сгенерировано gen_v7d.py: модель «echo_sovereign». */
public class SovereignModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(VoidbloomMod.id("echo_sovereign"), "main");
    private final ModelPart root;
    private final ModelPart p_all;
    private final ModelPart p_hem;
    private final ModelPart p_mid;
    private final ModelPart p_chest;
    private final ModelPart p_core;
    private final ModelPart p_shL;
    private final ModelPart p_spL;
    private final ModelPart p_armL;
    private final ModelPart p_handL;
    private final ModelPart p_shR;
    private final ModelPart p_spR;
    private final ModelPart p_armR;
    private final ModelPart p_handR;
    private final ModelPart p_head;
    private final ModelPart p_c0;
    private final ModelPart p_c1;
    private final ModelPart p_c2;
    private final ModelPart p_c3;
    private final ModelPart p_c4;
    private final ModelPart p_bc0;
    private final ModelPart p_bc1;
    private final ModelPart p_bc2;
    private final ModelPart p_s0;
    private final ModelPart p_s1;
    private final ModelPart p_s2;
    private final ModelPart p_s3;
    private final ModelPart p_s4;
    private final ModelPart p_s5;

    public SovereignModel(ModelPart root) {
        this.root = root;
        this.p_all = root.getChild("all");
        this.p_hem = root.getChild("all").getChild("hem");
        this.p_mid = root.getChild("all").getChild("mid");
        this.p_chest = root.getChild("all").getChild("chest");
        this.p_core = root.getChild("all").getChild("core");
        this.p_shL = root.getChild("all").getChild("shL");
        this.p_spL = root.getChild("all").getChild("spL");
        this.p_armL = root.getChild("all").getChild("armL");
        this.p_handL = root.getChild("all").getChild("armL").getChild("handL");
        this.p_shR = root.getChild("all").getChild("shR");
        this.p_spR = root.getChild("all").getChild("spR");
        this.p_armR = root.getChild("all").getChild("armR");
        this.p_handR = root.getChild("all").getChild("armR").getChild("handR");
        this.p_head = root.getChild("all").getChild("head");
        this.p_c0 = root.getChild("all").getChild("head").getChild("c0");
        this.p_c1 = root.getChild("all").getChild("head").getChild("c1");
        this.p_c2 = root.getChild("all").getChild("head").getChild("c2");
        this.p_c3 = root.getChild("all").getChild("head").getChild("c3");
        this.p_c4 = root.getChild("all").getChild("head").getChild("c4");
        this.p_bc0 = root.getChild("all").getChild("bc0");
        this.p_bc1 = root.getChild("all").getChild("bc1");
        this.p_bc2 = root.getChild("all").getChild("bc2");
        this.p_s0 = root.getChild("all").getChild("s0");
        this.p_s1 = root.getChild("all").getChild("s1");
        this.p_s2 = root.getChild("all").getChild("s2");
        this.p_s3 = root.getChild("all").getChild("s3");
        this.p_s4 = root.getChild("all").getChild("s4");
        this.p_s5 = root.getChild("all").getChild("s5");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition d_all = root.addOrReplaceChild("all", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_hem = d_all.addOrReplaceChild("hem", CubeListBuilder.create().texOffs(44, 0).addBox(-8.0F, -12.0F, -7.0F, 16.0F, 12.0F, 14.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_mid = d_all.addOrReplaceChild("mid", CubeListBuilder.create().texOffs(0, 28).addBox(-6.0F, -14.0F, -5.0F, 12.0F, 14.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_chest = d_all.addOrReplaceChild("chest", CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -20.0F, -4.0F, 14.0F, 20.0F, 8.0F), PartPose.offsetAndRotation(0.0F, -26.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_core = d_all.addOrReplaceChild("core", CubeListBuilder.create().texOffs(84, 84).addBox(-3.0F, -3.0F, -1.0F, 6.0F, 6.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.0F, -4.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_shL = d_all.addOrReplaceChild("shL", CubeListBuilder.create().texOffs(16, 52).addBox(-4.0F, -6.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(10.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_spL = d_all.addOrReplaceChild("spL", CubeListBuilder.create().texOffs(80, 52).addBox(-1.5F, -12.0F, -1.5F, 3.0F, 12.0F, 3.0F), PartPose.offsetAndRotation(10.0F, -50.0F, 0.0F, 0.0F, 0.0F, 0.4F));
        PartDefinition d_armL = d_all.addOrReplaceChild("armL", CubeListBuilder.create().texOffs(84, 28).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 14.0F, 5.0F), PartPose.offsetAndRotation(13.0F, -42.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_handL = d_armL.addOrReplaceChild("handL", CubeListBuilder.create().texOffs(0, 70).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 7.0F, 7.0F), PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_shR = d_all.addOrReplaceChild("shR", CubeListBuilder.create().texOffs(48, 52).addBox(-4.0F, -6.0F, -4.0F, 8.0F, 8.0F, 8.0F), PartPose.offsetAndRotation(-10.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_spR = d_all.addOrReplaceChild("spR", CubeListBuilder.create().texOffs(92, 52).addBox(-1.5F, -12.0F, -1.5F, 3.0F, 12.0F, 3.0F), PartPose.offsetAndRotation(-10.0F, -50.0F, 0.0F, 0.0F, 0.0F, -0.4F));
        PartDefinition d_armR = d_all.addOrReplaceChild("armR", CubeListBuilder.create().texOffs(104, 28).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 14.0F, 5.0F), PartPose.offsetAndRotation(-13.0F, -42.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_handR = d_armR.addOrReplaceChild("handR", CubeListBuilder.create().texOffs(28, 70).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 7.0F, 7.0F), PartPose.offsetAndRotation(0.0F, 14.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_head = d_all.addOrReplaceChild("head", CubeListBuilder.create().texOffs(44, 28).addBox(-5.0F, -10.0F, -5.0F, 10.0F, 10.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -46.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_c0 = d_head.addOrReplaceChild("c0", CubeListBuilder.create().texOffs(56, 70).addBox(-1.5F, -10.0F, -1.5F, 3.0F, 10.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_c1 = d_head.addOrReplaceChild("c1", CubeListBuilder.create().texOffs(92, 70).addBox(-1.5F, -7.0F, -1.5F, 3.0F, 7.0F, 3.0F), PartPose.offsetAndRotation(-4.0F, -10.0F, 0.0F, 0.0F, 0.0F, -0.35F));
        PartDefinition d_c2 = d_head.addOrReplaceChild("c2", CubeListBuilder.create().texOffs(104, 70).addBox(-1.5F, -7.0F, -1.5F, 3.0F, 7.0F, 3.0F), PartPose.offsetAndRotation(4.0F, -10.0F, 0.0F, 0.0F, 0.0F, 0.35F));
        PartDefinition d_c3 = d_head.addOrReplaceChild("c3", CubeListBuilder.create().texOffs(116, 70).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -4.0F, -0.35F, 0.0F, 0.0F));
        PartDefinition d_c4 = d_head.addOrReplaceChild("c4", CubeListBuilder.create().texOffs(0, 84).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 4.0F, 0.35F, 0.0F, 0.0F));
        PartDefinition d_bc0 = d_all.addOrReplaceChild("bc0", CubeListBuilder.create().texOffs(0, 52).addBox(-2.0F, -14.0F, -2.0F, 4.0F, 14.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -38.0F, 6.0F, 0.5F, 0.0F, 0.0F));
        PartDefinition d_bc1 = d_all.addOrReplaceChild("bc1", CubeListBuilder.create().texOffs(68, 70).addBox(-1.5F, -10.0F, -1.5F, 3.0F, 10.0F, 3.0F), PartPose.offsetAndRotation(-5.0F, -36.0F, 6.0F, 0.4F, 0.0F, -0.3F));
        PartDefinition d_bc2 = d_all.addOrReplaceChild("bc2", CubeListBuilder.create().texOffs(80, 70).addBox(-1.5F, -10.0F, -1.5F, 3.0F, 10.0F, 3.0F), PartPose.offsetAndRotation(5.0F, -36.0F, 6.0F, 0.4F, 0.0F, 0.3F));
        PartDefinition d_s0 = d_all.addOrReplaceChild("s0", CubeListBuilder.create().texOffs(12, 84).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_s1 = d_all.addOrReplaceChild("s1", CubeListBuilder.create().texOffs(24, 84).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_s2 = d_all.addOrReplaceChild("s2", CubeListBuilder.create().texOffs(36, 84).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_s3 = d_all.addOrReplaceChild("s3", CubeListBuilder.create().texOffs(48, 84).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_s4 = d_all.addOrReplaceChild("s4", CubeListBuilder.create().texOffs(60, 84).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_s5 = d_all.addOrReplaceChild("s5", CubeListBuilder.create().texOffs(72, 84).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -44.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        boolean aggro = entity instanceof Mob m && m.isAggressive();
        float t = age;
        p_all.y = 24.0F + Mth.sin(t * 0.08F) * 1.5F;
        p_head.yRot = yaw * 0.017453292F;
        p_head.xRot = pitch * 0.017453292F;
        float raise = aggro ? -1.3F + Mth.sin(t * 0.3F) * 0.15F : Mth.cos(limbSwing * 0.4F) * 0.5F * limbSwingAmount;
        p_armR.xRot = raise;
        p_armL.xRot = aggro ? raise : -raise;
        p_armR.zRot = 0.12F + Mth.sin(t * 0.07F) * 0.05F;
        p_armL.zRot = -0.12F - Mth.sin(t * 0.07F) * 0.05F;
        p_core.xScale = p_core.yScale = p_core.zScale = 1.0F + Mth.sin(t * 0.2F) * 0.15F;
        ModelPart[] sh = {p_s0, p_s1, p_s2, p_s3, p_s4, p_s5};
        for (int i = 0; i < 6; i++) {
            float a = t * (aggro ? 0.12F : 0.05F) + i * 1.0472F;
            sh[i].x = Mth.cos(a) * 17.0F;
            sh[i].z = Mth.sin(a) * 17.0F;
            sh[i].y = -44.0F + Mth.sin(t * 0.1F + i) * 4.0F;
            sh[i].yRot = -a;
            sh[i].xRot = t * 0.1F + i;
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
