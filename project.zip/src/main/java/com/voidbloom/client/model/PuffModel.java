package com.voidbloom.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/** Сгенерировано gen_v7d.py: модель «glow_puff». */
public class PuffModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(VoidbloomMod.id("glow_puff"), "main");
    private final ModelPart root;
    private final ModelPart p_body;
    private final ModelPart p_head;
    private final ModelPart p_tail;
    private final ModelPart p_l0;
    private final ModelPart p_l1;
    private final ModelPart p_l2;
    private final ModelPart p_l3;
    private final ModelPart p_t0;
    private final ModelPart p_t1;
    private final ModelPart p_t2;

    public PuffModel(ModelPart root) {
        this.root = root;
        this.p_body = root.getChild("body");
        this.p_head = root.getChild("body").getChild("head");
        this.p_tail = root.getChild("body").getChild("tail");
        this.p_l0 = root.getChild("l0");
        this.p_l1 = root.getChild("l1");
        this.p_l2 = root.getChild("l2");
        this.p_l3 = root.getChild("l3");
        this.p_t0 = root.getChild("body").getChild("t0");
        this.p_t1 = root.getChild("body").getChild("t1");
        this.p_t2 = root.getChild("body").getChild("t2");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition d_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-6.0F, -5.0F, -6.0F, 12.0F, 10.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 17.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_head = d_body.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 22).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 7.0F, 6.0F), PartPose.offsetAndRotation(0.0F, -1.0F, -6.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_tail = d_body.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(28, 22).addBox(-2.5F, -2.5F, 0.0F, 5.0F, 5.0F, 4.0F), PartPose.offsetAndRotation(0.0F, 1.0F, 6.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_l0 = root.addOrReplaceChild("l0", CubeListBuilder.create().texOffs(0, 35).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(-3.5F, 21.0F, -3.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_l1 = root.addOrReplaceChild("l1", CubeListBuilder.create().texOffs(12, 35).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(3.5F, 21.0F, -3.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_l2 = root.addOrReplaceChild("l2", CubeListBuilder.create().texOffs(24, 35).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(-3.5F, 21.0F, 3.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_l3 = root.addOrReplaceChild("l3", CubeListBuilder.create().texOffs(36, 35).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.offsetAndRotation(3.5F, 21.0F, 3.5F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_t0 = d_body.addOrReplaceChild("t0", CubeListBuilder.create().texOffs(46, 22).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_t1 = d_body.addOrReplaceChild("t1", CubeListBuilder.create().texOffs(48, 35).addBox(-1.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(-3.0F, -5.0F, 2.0F, 0.0F, 0.0F, -0.5F));
        PartDefinition d_t2 = d_body.addOrReplaceChild("t2", CubeListBuilder.create().texOffs(56, 35).addBox(-1.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(3.0F, -5.0F, -2.0F, 0.0F, 0.0F, 0.5F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        boolean aggro = entity instanceof Mob m && m.isAggressive();
        float t = age;
        p_head.yRot = yaw * 0.017453292F;
        p_head.xRot = pitch * 0.017453292F;
        float sw = Mth.cos(limbSwing * 0.8F) * 1.2F * limbSwingAmount;
        p_l0.xRot = sw;
        p_l3.xRot = sw;
        p_l1.xRot = -sw;
        p_l2.xRot = -sw;
        p_tail.yRot = Mth.sin(t * 0.2F) * 0.3F;
        p_t0.zRot = Mth.sin(t * 0.12F) * 0.15F;
        p_t1.zRot = -0.5F + Mth.sin(t * 0.15F + 1.0F) * 0.15F;
        p_t2.zRot = 0.5F + Mth.sin(t * 0.15F + 2.0F) * 0.15F;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
