package com.voidbloom.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/** Сгенерировано gen_v7d.py: модель «echo_drifter». */
public class DrifterModel<T extends Entity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(VoidbloomMod.id("echo_drifter"), "main");
    private final ModelPart root;
    private final ModelPart p_all;
    private final ModelPart p_bell;
    private final ModelPart p_ta0;
    private final ModelPart p_ta1;
    private final ModelPart p_ta2;
    private final ModelPart p_ta3;
    private final ModelPart p_rb0;
    private final ModelPart p_rb1;
    private final ModelPart p_rb2;
    private final ModelPart p_rb3;

    public DrifterModel(ModelPart root) {
        this.root = root;
        this.p_all = root.getChild("all");
        this.p_bell = root.getChild("all").getChild("bell");
        this.p_ta0 = root.getChild("all").getChild("ta0");
        this.p_ta1 = root.getChild("all").getChild("ta1");
        this.p_ta2 = root.getChild("all").getChild("ta2");
        this.p_ta3 = root.getChild("all").getChild("ta3");
        this.p_rb0 = root.getChild("all").getChild("rb0");
        this.p_rb1 = root.getChild("all").getChild("rb1");
        this.p_rb2 = root.getChild("all").getChild("rb2");
        this.p_rb3 = root.getChild("all").getChild("rb3");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition d_all = root.addOrReplaceChild("all", CubeListBuilder.create(), PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_bell = d_all.addOrReplaceChild("bell", CubeListBuilder.create().texOffs(0, 33).addBox(-5.0F, -7.0F, -5.0F, 10.0F, 4.0F, 10.0F).texOffs(0, 18).addBox(-6.0F, -3.0F, -6.0F, 12.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_ta0 = d_all.addOrReplaceChild("ta0", CubeListBuilder.create().texOffs(40, 33).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F), PartPose.offsetAndRotation(-3.0F, -15.0F, -3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_ta1 = d_all.addOrReplaceChild("ta1", CubeListBuilder.create().texOffs(48, 33).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F), PartPose.offsetAndRotation(3.0F, -15.0F, -3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_ta2 = d_all.addOrReplaceChild("ta2", CubeListBuilder.create().texOffs(56, 33).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F), PartPose.offsetAndRotation(-3.0F, -15.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_ta3 = d_all.addOrReplaceChild("ta3", CubeListBuilder.create().texOffs(0, 47).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 10.0F, 2.0F), PartPose.offsetAndRotation(3.0F, -15.0F, 3.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_rb0 = d_all.addOrReplaceChild("rb0", CubeListBuilder.create().texOffs(0, 0).addBox(-0.5F, 0.0F, -1.0F, 1.0F, 16.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_rb1 = d_all.addOrReplaceChild("rb1", CubeListBuilder.create().texOffs(6, 0).addBox(-0.5F, 0.0F, -1.0F, 1.0F, 16.0F, 2.0F), PartPose.offsetAndRotation(5.0F, -15.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_rb2 = d_all.addOrReplaceChild("rb2", CubeListBuilder.create().texOffs(12, 0).addBox(-0.5F, 0.0F, -1.0F, 1.0F, 16.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -15.0F, -5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition d_rb3 = d_all.addOrReplaceChild("rb3", CubeListBuilder.create().texOffs(18, 0).addBox(-0.5F, 0.0F, -1.0F, 1.0F, 16.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -15.0F, 5.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        boolean aggro = entity instanceof Mob m && m.isAggressive();
        float t = age;
        float pulse = Mth.sin(t * 0.2F);
        p_bell.yScale = 1.0F + pulse * 0.12F;
        p_bell.xScale = 1.0F - pulse * 0.06F;
        p_bell.zScale = 1.0F - pulse * 0.06F;
        ModelPart[] ta = {p_ta0, p_ta1, p_ta2, p_ta3};
        ModelPart[] rb = {p_rb0, p_rb1, p_rb2, p_rb3};
        for (int i = 0; i < 4; i++) {
            ta[i].xRot = Mth.sin(t * 0.15F + i) * 0.25F;
            ta[i].zRot = Mth.cos(t * 0.13F + i) * 0.25F;
            rb[i].xRot = Mth.sin(t * 0.12F + i * 1.7F) * 0.4F;
            rb[i].zRot = Mth.cos(t * 0.1F + i * 1.3F) * 0.4F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(ps, vc, light, overlay, r, g, b, a);
    }
}
