# Voidbloom: Realm of Echoes (Fabric 1.20.1)

Порт мода на Minecraft 1.20.1 / Fabric (Java 17, Fabric API 0.92.2+1.20.1, Mojang mappings).
Сборка: `gradle build` -> `build/libs/voidbloom-*.jar`. Требуется Fabric Loader >= 0.15 и Fabric API.
